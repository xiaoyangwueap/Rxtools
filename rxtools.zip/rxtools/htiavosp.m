function varargout = htiavosp(varargin)
% HTIAVOSP MATLAB code for htiavosp.fig
%      HTIAVOSP, by itself, creates a new HTIAVOSP or raises the existing
%      singleton*.
%
%      H = HTIAVOSP returns the handle to a new HTIAVOSP or the handle to
%      the existing singleton*.
%
%      HTIAVOSP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HTIAVOSP.M with the given input arguments.
%
%      HTIAVOSP('Property','Value',...) creates a new HTIAVOSP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before htiavosp_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to htiavosp_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help htiavosp

% Last Modified by GUIDE v2.5 10-Mar-2015 17:25:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @htiavosp_OpeningFcn, ...
                   'gui_OutputFcn',  @htiavosp_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before htiavosp is made visible.
function htiavosp_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to htiavosp (see VARARGIN)

% Choose default command line output for htiavosp
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes htiavosp wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global Flag_1;
Flag_1=1;
htiavosp_draw(handles);


% --- Outputs from this function are returned to the command line.
function varargout = htiavosp_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ok.
function ok_Callback(hObject, eventdata, handles)
% hObject    handle to ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
htiavosp_draw(handles);


% --- Executes on button press in cancel.
function cancel_Callback(hObject, eventdata, handles)
% hObject    handle to cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(htiavosp);

% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a = get(handles.edit14,'String');
if isempty(a),
    msgbox('Please specify a file path!');
else
    savedata();
end


function htiavosp_draw(handles)
global ang Rpp1 Rpp2 Rpp3 Rpp33 Rpp4;
global Rps1 Rps2 Rps3 Rps33 Rps4;
global Rpt1 Rpt2 Rpt3 Rpt33 Rpt4;
global Rsp1 Rsp2 Rsp3 Rsp33 Rsp4;
global Rss1 Rss2 Rss3 Rss33 Rss4;
global Rst1 Rst2 Rst3 Rst33 Rst4;
global Rtp1 Rtp2 Rtp3 Rtp33 Rtp4;
global Rts1 Rts2 Rts3 Rts33 Rts4;
global Rtt1 Rtt2 Rtt3 Rtt33 Rtt4;
global Flag_1 angle;
global C111 C131 C331 C441 C661 RHO1;
global C112 C132 C332 C442 C662 RHO2;
C111 = str2num(get(handles.edit1,'String'));
C131 = str2num(get(handles.edit2,'String'));
C331 = str2num(get(handles.edit3,'String'));
C441 = str2num(get(handles.edit4,'String'));
C661 = str2num(get(handles.edit5,'String'));
RHO1 = str2num(get(handles.edit6,'String'));
CC1(1) = C111;CC1(2) = C131;CC1(3) = C331;CC1(4) = C441;CC1(5) = C661;

C112 = str2num(get(handles.edit7,'String'));
C132 = str2num(get(handles.edit8,'String'));
C332 = str2num(get(handles.edit9,'String'));
C442 = str2num(get(handles.edit10,'String'));
C662 = str2num(get(handles.edit11,'String'));
RHO2 = str2num(get(handles.edit12,'String'));
CC2(1) = C112;CC2(2) = C132;CC2(3) = C332;CC2(4) = C442;CC2(5) = C662;

angle = str2num(get(handles.edit13,'String'));
[Rpp1,Rps1,Rpt1,Rsp1,Rss1,Rst1,Rtp1,Rts1,Rtt1,ang]=htischpron(CC1,RHO1,CC2,RHO2,0,angle);
[Rpp2,Rps2,Rpt2,Rsp2,Rss2,Rst2,Rtp2,Rts2,Rtt2,ang]=htischpron(CC1,RHO1,CC2,RHO2,30,angle);
[Rpp3,Rps3,Rpt3,Rsp3,Rss3,Rst3,Rtp3,Rts3,Rtt3,ang]=htischpron(CC1,RHO1,CC2,RHO2,45,angle);
[Rpp33,Rps33,Rpt33,Rsp33,Rss33,Rst33,Rtp33,Rts33,Rtt33,ang]=htischpron(CC1,RHO1,CC2,RHO2,60,angle);
[Rpp4,Rps4,Rpt4,Rsp4,Rss4,Rst4,Rtp4,Rts4,Rtt4,ang]=htischpron(CC1,RHO1,CC2,RHO2,90,angle);

cla(handles.axes1,'reset');
cla(handles.axes2,'reset');
cla(handles.axes3,'reset');
axes(handles.axes1);

if Flag_1 == 1,
    plot(ang(1:50),Rpp1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rpp2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rpp3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rpp33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rpp4(1:50),'k','linewidth',2);
    ylabel('Rp-p');
elseif Flag_1 == 2,
    plot(ang(1:50),Rsp1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rsp2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rsp3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rsp33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rsp4(1:50),'k','linewidth',2);
    ylabel('Rsv-p');
elseif Flag_1 == 3,
    plot(ang(1:50),Rtp1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rtp2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rtp3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rtp33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rtp4(1:50),'k','linewidth',2);
    ylabel('Rsh-p');
end
xlim([0 50]);
legend('0^{0}','30^{0}','45^{0}','60^{0}','90^{0}');
xlabel('Incident angle');
grid on;

axes(handles.axes2);
if Flag_1 == 1,
    plot(ang(1:50),Rps1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rps2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rps3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rps33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rps4(1:50),'k','linewidth',2);
    ylabel('Rp-sv');
elseif Flag_1==2,
    plot(ang(1:50),Rss1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rss2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rss3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rss33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rss4(1:50),'k','linewidth',2);
    ylabel('Rsv-sv');
elseif Flag_1==3,
    plot(ang(1:50),Rts1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rts2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rts3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rts33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rts4(1:50),'k','linewidth',2);
    ylabel('Rsh-sv');
end
xlim([0 50]);
legend('0^{0}','30^{0}','45^{0}','60^{0}','90^{0}');
xlabel('Incident angle');

grid on;

axes(handles.axes3);
if Flag_1 == 1,
    plot(ang(1:50),Rpt1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rpt2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rpt3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rpt33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rpt4(1:50),'k','linewidth',2);
    ylabel('Rp-sh');
elseif Flag_1==2,
    plot(ang(1:50),Rst1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rst2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rst3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rst33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rst4(1:50),'k','linewidth',2);
    ylabel('Rsv-sh');
elseif Flag_1==3,
    plot(ang(1:50),Rtt1(1:50),'r','linewidth',2);hold on;
    plot(ang(1:50),Rtt2(1:50),'g','linewidth',2);hold on;
    plot(ang(1:50),Rtt3(1:50),'b','linewidth',2);hold on;
    plot(ang(1:50),Rtt33(1:50),'m','linewidth',2);hold on;
    plot(ang(1:50),Rtt4(1:50),'k','linewidth',2);
    ylabel('Rsh-sh');
end
xlim([0 50]);
legend('0^{0}','30^{0}','45^{0}','60^{0}','90^{0}');
xlabel('Incident angle');
grid on;

function savedata()
global Rpp1 Rpp2 Rpp3 Rpp33 Rpp4;
global Rps1 Rps2 Rps3 Rps33 Rps4;
global Rpt1 Rpt2 Rpt3 Rpt33 Rpt4;
global Rsp1 Rsp2 Rsp3 Rsp33 Rsp4;
global Rss1 Rss2 Rss3 Rss33 Rss4;
global Rst1 Rst2 Rst3 Rst33 Rst4;
global Rtp1 Rtp2 Rtp3 Rtp33 Rtp4;
global Rts1 Rts2 Rts3 Rts33 Rts4;
global Rtt1 Rtt2 Rtt3 Rtt33 Rtt4;
global str angle;
global C111 C131 C331 C441 C661 RHO1;
global C112 C132 C332 C442 C662 RHO2;

File = str;
[fidGrd, msg] = fopen(File,'wt');
fprintf(fidGrd,'UPPER\tUPPER\tUPPER\tUPPER\tUPPER\tUPPER\tLOWER\tLOWER\tLOWER\tLOWER\tLOWER\tLOWER\tLOWER\tINC\tPROP\t');
fprintf(fidGrd,'INC_0\tINC_10\tINC_20\tINC_30\tINC_40\tINC_50\tINC_0\tINC_10\tINC_20\tINC_30\tINC_40\tINC_50\tINC_0\tINC_10\tINC_20\t');
fprintf(fidGrd,'INC_30\tINC_40\tINC_50\tINC_0\tINC_10\tINC_20\tINC_30\tINC_40\tINC_50\tINC_0\tINC_10\tINC_20\tINC_30\tINC_40\tINC_50\t\n');

fprintf(fidGrd,'C11\tC12\tC33\tC44\tD66\tRHO\tC11\tC12\tC33\tC44\tC66\tRHO\tHTI\tMODE\tMODE\t');
fprintf(fidGrd,'AZI_0\tAZI_0\tAZI_0\tAZI_0\tAZI_0\tAZI_0\tAZI_30\tAZI_30\tAZI_30\tAZI_30\tAZI_30\tAZI_30\tAZI_45\tAZI_45\tAZI_45\t');
fprintf(fidGrd,'AZI_45\tAZI_45\tAZI_45\tAZI_60\tAZI_60\tAZI_60\tAZI_60\tAZI_60\tAZI_60\tAZI_90\tAZI_90\tAZI_90\tAZI_90\tAZI_90\tAZI_90\t\n');

fprintf(fidGrd,'GPa\tGPa\tGPa\tGPa\tGPa\tg/cc\tGPa\tGPa\tGPa\tGPa\tGPa\tg/cc\tdeg\talpha\talpha\t');
fprintf(fidGrd,'ref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\t');
fprintf(fidGrd,'ref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\tref\t\n');

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'P\tP\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpp1(1),Rpp1(11),Rpp1(21),Rpp1(31),Rpp1(41),Rpp1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpp2(1),Rpp2(11),Rpp2(21),Rpp2(31),Rpp2(41),Rpp2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpp3(1),Rpp3(11),Rpp3(21),Rpp3(31),Rpp3(41),Rpp3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpp33(1),Rpp33(11),Rpp33(21),Rpp33(31),Rpp33(41),Rpp33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rpp4(1),Rpp4(11),Rpp4(21),Rpp4(31),Rpp4(41),Rpp4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'P\tSV\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rps1(1),Rps1(11),Rps1(21),Rps1(31),Rps1(41),Rps1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rps2(1),Rps2(11),Rps2(21),Rps2(31),Rps2(41),Rps2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rps3(1),Rps3(11),Rps3(21),Rps3(31),Rps3(41),Rps3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rps33(1),Rps33(11),Rps33(21),Rps33(31),Rps33(41),Rps33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rps4(1),Rps4(11),Rps4(21),Rps4(31),Rps4(41),Rps4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'P\tSH\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpt1(1),Rpt1(11),Rpt1(21),Rpt1(31),Rpt1(41),Rpt1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpt2(1),Rpt2(11),Rpt2(21),Rpt2(31),Rpt2(41),Rpt2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpt3(1),Rpt3(11),Rpt3(21),Rpt3(31),Rpt3(41),Rpt3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rpt33(1),Rpt33(11),Rpt33(21),Rpt33(31),Rpt33(41),Rpt33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rpt4(1),Rpt4(11),Rpt4(21),Rpt4(31),Rpt4(41),Rpt4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'SV\tP\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rsp1(1),Rsp1(11),Rsp1(21),Rsp1(31),Rsp1(41),Rsp1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rsp2(1),Rsp2(11),Rsp2(21),Rsp2(31),Rsp2(41),Rsp2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rsp3(1),Rsp3(11),Rsp3(21),Rsp3(31),Rsp3(41),Rsp3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rsp33(1),Rsp33(11),Rsp33(21),Rsp33(31),Rsp33(41),Rsp33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rsp4(1),Rsp4(11),Rsp4(21),Rsp4(31),Rsp4(41),Rsp4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'SV\tSV\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rss1(1),Rss1(11),Rss1(21),Rss1(31),Rss1(41),Rss1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rss2(1),Rss2(11),Rss2(21),Rss2(31),Rss2(41),Rss2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rss3(1),Rss3(11),Rss3(21),Rss3(31),Rss3(41),Rss3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rss33(1),Rss33(11),Rss33(21),Rss33(31),Rss33(41),Rss33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rss4(1),Rss4(11),Rss4(21),Rss4(31),Rss4(41),Rss4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'SV\tSH\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rst1(1),Rst1(11),Rst1(21),Rst1(31),Rst1(41),Rst1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rst2(1),Rst2(11),Rst2(21),Rst2(31),Rst2(41),Rst2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rst3(1),Rst3(11),Rst3(21),Rst3(31),Rst3(41),Rst3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rst33(1),Rst33(11),Rst33(21),Rst33(31),Rst33(41),Rst33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rst4(1),Rst4(11),Rst4(21),Rst4(31),Rst4(41),Rst4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'SH\tP\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtp1(1),Rtp1(11),Rtp1(21),Rtp1(31),Rtp1(41),Rtp1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtp2(1),Rtp2(11),Rtp2(21),Rtp2(31),Rtp2(41),Rtp2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtp3(1),Rtp3(11),Rtp3(21),Rtp3(31),Rtp3(41),Rtp3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtp33(1),Rtp33(11),Rtp33(21),Rtp33(31),Rtp33(41),Rtp33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rtp4(1),Rtp4(11),Rtp4(21),Rtp4(31),Rtp4(41),Rtp4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'SH\tSV\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rts1(1),Rts1(11),Rts1(21),Rts1(31),Rts1(41),Rts1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rts2(1),Rts2(11),Rts2(21),Rts2(31),Rts2(41),Rts2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rts3(1),Rts3(11),Rts3(21),Rts3(31),Rts3(41),Rts3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rts33(1),Rts33(11),Rts33(21),Rts33(31),Rts33(41),Rts33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t\n', Rts4(1),Rts4(11),Rts4(21),Rts4(31),Rts4(41),Rts4(51));

fprintf(fidGrd,'%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.2f\t%5.3f\t%d\t', C111, C131, C331, C441, C661, RHO1, C112, C132, C332, C442, C662, RHO2, angle);
fprintf(fidGrd,'SH\tSH\t');
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtt1(1),Rtt1(11),Rtt1(21),Rtt1(31),Rtt1(41),Rtt1(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtt2(1),Rtt2(11),Rtt2(21),Rtt2(31),Rtt2(41),Rtt2(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtt3(1),Rtt3(11),Rtt3(21),Rtt3(31),Rtt3(41),Rtt3(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtt33(1),Rtt33(11),Rtt33(21),Rtt33(31),Rtt33(41),Rtt33(51));
fprintf(fidGrd,'%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t%6.4f\t', Rtt4(1),Rtt4(11),Rtt4(21),Rtt4(31),Rtt4(41),Rtt4(51));
fclose(fidGrd);
msgbox('File has been saved!');


function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes when selected object is changed in uipanel4.
function uipanel4_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel4 
% eventdata  structure with the following fields (see UIBUTTONGROUP)
%	EventName: string 'SelectionChanged' (read only)
%	OldValue: handle of the previously selected object or empty if none was selected
%	NewValue: handle of the currently selected object
% handles    structure with handles and user data (see GUIDATA)
global Flag_1;
switch get(eventdata.NewValue,'Tag') % Get Tag of selected object.
       case 'radiobutton1'
           Flag_1=1;
       case 'radiobutton2'
           Flag_1=2;
       case 'radiobutton3'
           Flag_1=3;
    otherwise;
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global str pathname;
[filename ,pathname] = uiputfile({'*.txt','TEXT-files(*.txt)'},'save as');
str = strcat(pathname,filename);
set(handles.edit14,'String',str);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
htiavosp_draw(handles);



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double


% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% % --- Executes on button press in okl.
% function okl_Callback(hObject, eventdata, handles)
% % hObject    handle to okl (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global C112 C132 C332 C442 C662 RHO2;
% C112 = str2num(get(handles.edit7,'String'));
% C132 = str2num(get(handles.edit8,'String'));
% C332 = str2num(get(handles.edit9,'String'));
% C442 = str2num(get(handles.edit10,'String'));
% C662 = str2num(get(handles.edit11,'String'));
% RHO2 = str2num(get(handles.edit12,'String'));
% 
% 
% % --- Executes on button press in oku.
% function oku_Callback(hObject, eventdata, handles)
% % hObject    handle to oku (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% global C111 C131 C331 C441 C661 RHO1;
% C111 = str2num(get(handles.edit1,'String'));
% C131 = str2num(get(handles.edit2,'String'));
% C331 = str2num(get(handles.edit3,'String'));
% C441 = str2num(get(handles.edit4,'String'));
% C661 = str2num(get(handles.edit5,'String'));
% RHO1 = str2num(get(handles.edit6,'String'));
