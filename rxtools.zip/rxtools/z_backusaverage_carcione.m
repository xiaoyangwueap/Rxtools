function [c_eff, ThomsenAniso_eff, rho_eff] = z_backusaverage_carcione(...
           f, ThomsenAniso, Rho) 
% ----------------------------------------------------------------------- %
% [ThomsenAniso_eff, Rho_eff] = z_backusaverage_carcione(...
%            f, ThomsenAniso, Rho) 
% Backus average of anisotropic version 
% based on the theory of Carcione
% Reference:
% Carcione, 2001, AVO effects of a hydrocarbon source-rock layer,
% Geophysics, 66, P.419--427
% 
% Input:
%     f            : fraction of compositions
%     ThomsenAniso : matrix of vp, vs, eps, delt, gamma
%                    velocity unit in (km/s)
%                    row is compositon
%                    column is vs, vs and anisotropy parameters
%     Rho          : array of density, unit in (kg/m3)
% 
% Output:
%     ThomsenAniso_eff : matrix of vp, vs, eps, delt, gamma
%                        velocity unit in (km/s)
%                        row is compositon
%                        column is vs, vs and anisotropy parameters
%     Rho_eff          : array of density, unit in (kg/m3)
% 
% Written by Zhiqi Guo on 21 Mar 2012
% ----------------------------------------------------------------------- %

%% 1 - from Thomsen anisotropic parameters to Cij
[row, column] = size(ThomsenAniso);

for i = 1:row
    vp(i)    = ThomsenAniso(i,1);
    vs(i)    = ThomsenAniso(i,2);
    eps(i)   = ThomsenAniso(i,3);
    delt(i)  = ThomsenAniso(i,4);
    gamma(i) = ThomsenAniso(i,5);
    rho(i)   = Rho(i);

    c   = z_thomsen2cVTI(rho(i),vp(i),vs(i),eps(i),delt(i),gamma(i));
    c11(i) = c(1,1);
    c33(i) = c(3,3);
    c13(i) = c(1,3);
    c44(i) = c(4,4);
    c66(i) = c(6,6);
end 

%% 2 - Backus Average of anisotropic version
c11_eff = sum(f.*(c11-((c13.^2)./c33))) + (1./sum((f.*(1./c33)))).*(sum(f.*(c13./c33))).^2;
c33_eff = 1./(sum(f.*(1./c33)));
c13_eff = (1./(sum(f.*(1./c33)))).*sum((f.*(c13./c33)));
c44_eff = 1./(sum(f.*(1./c44)));
c66_eff = sum(f.*c66);

rho_eff = sum(f.*rho);

c_eff(1,1) = c11_eff;
c_eff(3,3) = c33_eff;
c_eff(1,3) = c13_eff;
c_eff(4,4) = c44_eff;
c_eff(6,6) = c66_eff;

%% 3 - from Cij to Thomsen anisotropic parameters
[vp_eff,vs_eff,eps_eff,delt_eff,gamma_eff] = z_c2thomsenVTI(c_eff,rho_eff);

ThomsenAniso_eff = [vp_eff,vs_eff,eps_eff,delt_eff,gamma_eff]; 






