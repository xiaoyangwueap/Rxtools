function [RPP RPS TPP TPS] = avo4vti(Property_1,Property_2)
% ----------------------------------------------------------------------- %
% function [RPP RPS TPP TPS] = z_AVOInterfaceVTI(Property_1,Property_2)
% 
% Calcuate reflection and transmission coefficients from an interface
% between two VTI layers
% Input:
%       Property_1: Vp_1,Vs_1,eps_1,delt_1,gamma_1,rho_1,Qp_1,Qs_1
%                    m/s    kg/m3                         100  80
%       Property_2: Vp_2,Vs_2,eps_2,delt_2,gamma_2,rho_2,Qp_2,Qs_2
%                                                         20  15
%       f: dominant frequence of incidence wave
% Output:
%       RPP
%       RPS
%       TPP
%       TPS
% All coefficients are complex and are from 0 to 90 degree
% 
% Written by Zhiqi Guo 09 Dec 2011
% ----------------------------------------------------------------------- %

%% ---- from anisotropy parameters to velocities
   Vp_1 = Property_1(1);       Vp_2 = Property_2(1);
   Vs_1 = Property_1(2);       Vs_2 = Property_2(2);
  eps_1 = Property_1(3);      eps_2 = Property_2(3);
 delt_1 = Property_1(4);     delt_2 = Property_2(4);
gamma_1 = Property_1(5);    gamma_2 = Property_2(5);
  rho_1 = Property_1(6);      rho_2 = Property_2(6);
  Q01_1 = 100;                Q01_2 = 20;
  Q02_1 = 80;                 Q02_2 = 15;

Cij_1=thomsen2ten(rho_1,Vp_1,Vs_1,eps_1,delt_1,gamma_1);
Cij_2=thomsen2ten(rho_2,Vp_2,Vs_2,eps_2,delt_2,gamma_2);

Vij_1=sqrt(Cij_1/rho_1);
Vij_2=sqrt(Cij_2/rho_2);

f0=30;

%% ---- UpperLayer and LowerLayer
c11_1=rho_1*(Vij_1(1,1))^2;
c33_1=rho_1*(Vij_1(3,3))^2;
c55_1=rho_1*(Vij_1(5,5))^2;
c13_1=rho_1*(Vij_1(1,3))^2;

c11_2=rho_2*(Vij_2(1,1))^2;
c33_2=rho_2*(Vij_2(3,3))^2;
c55_2=rho_2*(Vij_2(5,5))^2;
c13_2=rho_2*(Vij_2(1,3))^2;


%% ---- BLOCK
omega=2*pi*f0;
tau0=1/(2*pi*f0);

taue1_1=(tau0/Q01_1)*((Q01_1^2+1)^(0.5)+1);
taue2_1=(tau0/Q02_1)*((Q02_1^2+1)^(0.5)+1);
taus1_1=(tau0/Q01_1)*((Q01_1^2+1)^(0.5)-1);
taus2_1=(tau0/Q02_1)*((Q02_1^2+1)^(0.5)-1);

taue1_2=(tau0/Q01_2)*((Q01_2^2+1)^(0.5)+1);
taue2_2=(tau0/Q02_2)*((Q02_2^2+1)^(0.5)+1);
taus1_2=(tau0/Q01_2)*((Q01_2^2+1)^(0.5)-1);
taus2_2=(tau0/Q02_2)*((Q02_2^2+1)^(0.5)-1);

eta1_1=(taus1_1)/(taue1_1);
eta2_1=(taus2_1)/(taue2_1);

eta1_2=(taus1_2)/(taue1_2);
eta2_2=(taus2_2)/(taue2_2);

M1_1=eta1_1*((1+i*omega*taue1_1)/(1+i*omega*taus1_1));
M2_1=eta2_1*((1+i*omega*taue2_1)/(1+i*omega*taus2_1));

M1_2=eta1_2*((1+i*omega*taue1_2)/(1+i*omega*taus1_2));
M2_2=eta2_2*((1+i*omega*taue2_2)/(1+i*omega*taus2_2));

D_1=0.5*(c11_1+c33_1);
K_1=D_1-c55_1;

D_2=0.5*(c11_2+c33_2);
K_2=D_2-c55_2;

% ----------------------------------------------------------------------- %

p11_1=c11_1-D_1+K_1*M1_1+c55_1*M2_1;
p33_1=c33_1-D_1+K_1*M1_1+c55_1*M2_1;
p13_1=c13_1-D_1+K_1*M1_1+c55_1*(2-M2_1);
p55_1=c55_1*M2_1;

p11_2=c11_2-D_2+K_2*M1_2+c55_2*M2_2;
p33_2=c33_2-D_2+K_2*M1_2+c55_2*M2_2;
p13_2=c13_2-D_2+K_2*M1_2+c55_2*(2-M2_2);
p55_2=c55_2*M2_2;
                                                                  
% ----------------------------------------------------------------------- % 

for theta = 0:1:90

    theta_1 = theta*(pi/180);

    E_1=sqrt(((p33_1-p55_1)*(cos(theta_1))^2-(p11_1-p55_1)*(sin(theta_1))^2)^2+((p13_1+p55_1)^2*(sin(2*theta_1))^2));
    V_1=sqrt(0.5*(1/rho_1)*(p55_1+p11_1*(sin(theta_1))^2+p33_1*(cos(theta_1))^2+E_1));

    sx=(sin(theta_1))/V_1;                      %   sx : horizontal slowness


    K1_p1=rho_1*((1/p55_1)+(1/p33_1))+(1/p55_1)*((p13_1/p33_1)*(p13_1+2*p55_1)-p11_1)*(sx^2);
    K1_p2=rho_2*((1/p55_2)+(1/p33_2))+(1/p55_2)*((p13_2/p33_2)*(p13_2+2*p55_2)-p11_2)*(sx^2);
    K1_s1=rho_1*((1/p55_1)+(1/p33_1))+(1/p55_1)*((p13_1/p33_1)*(p13_1+2*p55_1)-p11_1)*(sx^2);
    K1_s2=rho_2*((1/p55_2)+(1/p33_2))+(1/p55_2)*((p13_2/p33_2)*(p13_2+2*p55_2)-p11_2)*(sx^2);

    K2_p1=(1/p33_1)*(p11_1*sx^2-rho_1);
    K2_p2=(1/p33_2)*(p11_2*sx^2-rho_2);
    K2_s1=(1/p33_1)*(p11_1*sx^2-rho_1);
    K2_s2=(1/p33_2)*(p11_2*sx^2-rho_2);

    K3_p1=sx^2-(rho_1/p55_1);
    K3_p2=sx^2-(rho_2/p55_2);
    K3_s1=sx^2-(rho_1/p55_1);
    K3_s2=sx^2-(rho_2/p55_2);

    sz_p1=(1/(2^(0.5)))*sqrt(K1_p1-sqrt(K1_p1^2-4*K2_p1*K3_p1));
    sz_p2=(1/(2^(0.5)))*sqrt(K1_p2-sqrt(K1_p2^2-4*K2_p2*K3_p2));
    sz_s1=(1/(2^(0.5)))*sqrt(K1_s1+sqrt(K1_s1^2-4*K2_s1*K3_s1));
    sz_s2=(1/(2^(0.5)))*sqrt(K1_s2+sqrt(K1_s2^2-4*K2_s2*K3_s2));

    beta_p1=sqrt((p55_1*sx^2+p33_1*sz_p1^2-rho_1)/(p11_1*sx^2+p33_1*sz_p1^2+p55_1*(sx^2+sz_p1^2)-2*rho_1));
    beta_p2=sqrt((p55_2*sx^2+p33_2*sz_p2^2-rho_2)/(p11_2*sx^2+p33_2*sz_p2^2+p55_2*(sx^2+sz_p2^2)-2*rho_2));
    beta_s1=sqrt((p55_1*sx^2+p33_1*sz_s1^2-rho_1)/(p11_1*sx^2+p33_1*sz_s1^2+p55_1*(sx^2+sz_s1^2)-2*rho_1));
    beta_s2=sqrt((p55_2*sx^2+p33_2*sz_s2^2-rho_2)/(p11_2*sx^2+p33_2*sz_s2^2+p55_2*(sx^2+sz_s2^2)-2*rho_2));

    gamma_p1=sqrt((p11_1*sx^2+p55_1*sz_p1^2-rho_1)/(p11_1*sx^2+p33_1*sz_p1^2+p55_1*(sx^2+sz_p1^2)-2*rho_1));
    gamma_p2=sqrt((p11_2*sx^2+p55_2*sz_p2^2-rho_2)/(p11_2*sx^2+p33_2*sz_p2^2+p55_2*(sx^2+sz_p2^2)-2*rho_2));
    gamma_s1=-sqrt((p11_1*sx^2+p55_1*sz_s1^2-rho_1)/(p11_1*sx^2+p33_1*sz_s1^2+p55_1*(sx^2+sz_s1^2)-2*rho_1));
    gamma_s2=-sqrt((p11_2*sx^2+p55_2*sz_s2^2-rho_2)/(p11_2*sx^2+p33_2*sz_s2^2+p55_2*(sx^2+sz_s2^2)-2*rho_2));

    W_p1=p55_1*(gamma_p1*sx+beta_p1*sz_p1);
    W_p2=p55_2*(gamma_p2*sx+beta_p2*sz_p2);
    W_s1=p55_1*(gamma_s1*sx+beta_s1*sz_s1);
    W_s2=p55_2*(gamma_s2*sx+beta_s2*sz_s2);W_s2=p55_2*(gamma_s2*sx+beta_s2*sz_s2);W_s2=p55_2*(gamma_s2*sx+beta_s2*sz_s2);

    Z_p1=p13_1*beta_p1*sx+p33_1*gamma_p1*sz_p1;
    Z_p2=p13_2*beta_p2*sx+p33_2*gamma_p2*sz_p2;
    Z_s1=p13_1*beta_s1*sx+p33_1*gamma_s1*sz_s1;
    Z_s2=p13_2*beta_s2*sx+p33_2*gamma_s2*sz_s2;
                                                                
        A=[beta_p1 beta_s1 -beta_p2 -beta_s2;...
           gamma_p1 gamma_s1 gamma_p2 gamma_s2;...
           Z_p1 Z_s1 -Z_p2 -Z_s2;...
           W_p1 W_s1 W_p2 W_s2;];
        B=[-beta_p1 gamma_p1 -Z_p1 W_p1]';
        
        C=A\B;                                             
        R(:,(theta+1)) = C;         % Matrix of RPP RPS TPP TPS
  
end      %    end of "for" cycle
                                             
RPP=R(1,:);
RPS=R(2,:);
TPP=R(3,:);
TPS=R(4,:);


