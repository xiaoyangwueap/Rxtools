function varargout = odf(varargin)
% ODF MATLAB code for odf.fig
%      ODF, by itself, creates a new ODF or raises the existing
%      singleton*.
%
%      H = ODF returns the handle to a new ODF or the handle to
%      the existing singleton*.
%
%      ODF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ODF.M with the given input arguments.
%
%      ODF('Property','Value',...) creates a new ODF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before odf_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to odf_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help odf

% Last Modified by GUIDE v2.5 26-Apr-2014 12:39:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @odf_OpeningFcn, ...
                   'gui_OutputFcn',  @odf_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before odf is made visible.
function odf_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to odf (see VARARGIN)

% Choose default command line output for odf
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes odf wait for user response (see UIRESUME)
% uiwait(handles.figure1);
s = pwd;
s1 = strcat(s,'\icons\picture4.jpg');
G1 = imread(s1);
axes(handles.axes3);
image(G1);
set(handles.axes3,'visible','off')
c = get(handles.slider1,'Value');
odf_draw(c,handles);
odf_calculate(c,handles);

% --- Outputs from this function are returned to the command line.
function varargout = odf_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
c = get(handles.slider1,'Value');
odf_draw(c,handles);
odf_calculate(c,handles);
c=floor(c*100)/100;
set(handles.edit1,'String',num2str(c));

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
c=str2double(get(hObject,'String'));
if isnumeric(c) && c>=get(handles.slider1,'Min') && ...
     c<=get(handles.slider1,'Max'),
     set(handles.slider1,'Value',c);
else
     errordlg('You have entered an invalid number','MATLAB error');
end
odf_draw(c,handles);
odf_calculate(c,handles);

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
odf_calculate(c,handles);


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
odf_calculate(c,handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
odf_calculate(c,handles);

% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
odf_calculate(c,handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
odf_calculate(c,handles);

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function odf_draw(c,handles)
f200 = @(x)0.5*c^2/(8*pi*pi)./(c^2+x.^2*(1-c^2)).^1.5.*(3*x.^2-1);
f400 = @(x)0.125*c^2/(8*pi*pi)./(c^2+x.^2*(1-c^2)).^1.5.*(35*x.^4-30*x.^2+3);   % x = cos(theta)
W000 = 1/(4*sqrt(2)*pi^2);
W200 = sqrt(2.5)*quadl(f200,-1,1,1e-6);
W400 = sqrt(4.5)*quadl(f400,-1,1,1e-6);

for i = 1:181
    theta(i) = (i-1)*2/180*pi;
    x = cos(theta(i));
    cw(i) = c^2/(8*pi*pi)/(c^2+x^2*(1-c^2))^1.5;    % odf function
    cwl(i) = W000*sqrt(0.5)+W200*sqrt(2.5)*0.5*(3*x*x-1)+W400*sqrt(4.5)*0.125*(35*x^4-30*x^2+3);   % odf function resconstructed from legendre function
    cwx(i) = cw(i)*cos(theta(i));
    cwy(i) = cw(i)*sin(theta(i));
    cwlx(i) = cwl(i)*cos(theta(i));
    cwly(i) = cwl(i)*sin(theta(i));
end

cla(handles.axes1,'reset');
axes(handles.axes1);
plot(cwx,cwy,'r', 'LineWidth',1);hold on,
plot(cwlx,cwly,'b--', 'LineWidth',1);
legend('ODF','RODF');
xlabel('x');
ylabel('y');
a1=min(cwx)*1.5;a2=max(cwx)*1.5;
b1=min(cwy)*1.5;b2=max(cwy)*1.5;
xlim([a1 a2]);
ylim([b1 b2]);
grid on;
axis equal;

cla(handles.axes2,'reset');
axes(handles.axes2);
theta = 0:10:360;
theta1 = theta/180*3.14159;
n = length(theta);
for i = 1:n
    w(i) = c^2/(8*pi*pi)/(cos(theta1(i))^2+c^2*sin(theta1(i))^2)^1.5;
end
bar(theta,w);
xlabel('\theta(Degree)');
ylabel('probability density');


function odf_calculate(c,handles)
ca11=str2double(get(handles.edit2,'String'));
ca33=str2double(get(handles.edit3,'String'));
ca13=str2double(get(handles.edit4,'String'));
ca44=str2double(get(handles.edit5,'String'));
ca66=str2double(get(handles.edit6,'String'));

Ca = [ca11,ca33,ca13,ca44,ca66]';
%W = c^2./(c^2+(1-c^2)*x.^2).^3/2;
%P2 = 0.5*(3*x.^2-1);
%P4 = 0.125*(35*x.^4-30*x.^2+3);
f200 = @(x)0.5*c^2/(8*pi*pi)./(c^2+x.^2*(1-c^2)).^1.5.*(3*x.^2-1);
f400 = @(x)0.125*c^2/(8*pi*pi)./(c^2+x.^2*(1-c^2)).^1.5.*(35*x.^4-30*x.^2+3);   %x=cos(theta)

W000 = 1/(4*sqrt(2)*pi^2);
W200 = sqrt(2.5)*quadl(f200,-1,1,1e-6);
W400 = sqrt(4.5)*quadl(f400,-1,1,1e-6);
W200a = sqrt(2.5)/(4*pi^2);
W400a = sqrt(4.5)/(4*pi^2);
W200N = W200/W200a;
W400N = W400/W400a;
T000 = 1/15*[8 3 4 8 0;
      8 3 4 8 0;
      6 1 8 -4 -10;
      1 1 -2 6 5;
      1 1 -2 6 5];
T200 = 1/21*[8 -6 -2 -4 0;
     -16 12 4 8 0;
     -6 1 5 -4 14;
      1 1 -2 3 -7;
     -2 -2 4 -6 14];
T400 = 1/35*[3 3 -6 -12 0;
      8 8 -16 -32 0;
     -4 -4 8 16 0;
     -4 -4 8 16 0;
      1 1 -2 -4 0];
K = T000+W200N*T200+W400N*T400;
Cavg = K*Ca;
c11 = Cavg(1);
c33 = Cavg(2);
c13 = Cavg(3);
c44 = Cavg(4);
c66 = Cavg(5);

c11=floor(c11*100)/100;
set(handles.edit7,'String',num2str(c11));
c33=floor(c33*100)/100;
set(handles.edit8,'String',num2str(c33));
c13=floor(c13*100)/100;
set(handles.edit9,'String',num2str(c13));
c44=floor(c44*100)/100;
set(handles.edit10,'String',num2str(c44));
c66=floor(c66*100)/100;
set(handles.edit11,'String',num2str(c66));
