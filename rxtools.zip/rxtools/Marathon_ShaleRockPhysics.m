% ----------------------------------------------------------------------- %
% Shale Rock Physics 
% 
% Theory model of a shale rock physics model
%       output:
%           rock physics templates
%           anisotropy parameters
%           brittleness index
% 
% - Written by Zhiqi Guo on 18 Nov 2011
% - during the period of Marathon Bakken Shale Project
% - recently updated on 25 Mar 2012
% 
% Reference:
% Rock Physics Templates for Analysis of Brittleness Index, Mineralogy, and
% Porosity - A Barnett Shale Case Study. 74th EAGE Conference & Exhibition
% Abstracts, G027.
% 
% ----------------------------------------------------------------------- %
function Marathon_ShaleRockPhysics(Flag_11, Flag_2, Flag_3, PoreKerogen_perc, LaminatedClays_perc,...
                                    LaminatedKerogen_perc, Minerals_AspectRatio,...
                                    Fraction_Gas, Fraction_Oil, Fraction_Water,...
                                    ThomsenAniso_clay,Fraction_Kerogen,frac,handles)
% clc
% clear
% tic

%% --------------------------------------------------------------------- %% 
% ---- setting
%Flag_1 = 'Variation_between_Clay_Quartz';
                                        % 'Variation_between_Clay_Quartz'
                                        % 'Variation_between_Clay_Dolomite'
%Flag_2 = 1;
%Flag_3 =1;

%PoreKerogen_perc = 0.2;  % fraction of kerogen-related porosity in total porosity

%LaminatedClays_perc = 1.0;               % fraction of laminated clays      %Change

%LaminatedKerogen_perc = 0.5;               % fraction of laminated kerogen  %Change

if Flag_11 == 1,
    Flag_1 = 'Variation_between_Clay_Quartz';
elseif Flag_11 ==2,
    Flag_1 = 'Variation_between_Clay_Dolomite';
end

Porosity_range_1 = 0.00:0.04:0.2;      % total porosity for template
Porosity_range_2 = 0.0:0.01:0.20;      % total porosity for anisotropy parameter

Fraction_range_1 = 0.1:0.1:0.4;
Fraction_range_2 = 0.1:0.01:0.4;

AspectRatio_range = -1.0:-1.0;              % log10(AspectRatio)

TitleSize = 10;
LabelSize = 10;

% ---- general setting
Properties           = importdata('data\input_property_ShaleRockPhysics.txt');
Properties_All       = Properties.data;
%Minerals_AspectRatio = [1 1 0.01 0.01];        % 0.01 for kerogen and clays,no effect  %Change
Num_AspectRatio      = 100;           % 100 or higher won't matter too much            

% Fraction_Gas   = 0.5;                                                                  %Change
% Fraction_Oil   = 0.2;                                                                  %Change
% Fraction_Water = 0.3;                 % fraction of gas/oil/water in pores             %Change
% 
%   eps_clay =   0.33;                                                                   %Change
%  delt_clay =  -0.05;                                                                   %Change
% gamma_clay =   0.48;                                                                   %Change
% ThomsenAniso_clay = [eps_clay, delt_clay, gamma_clay];
                                % from 'Elastic moduli of anisotropic clay'

for process = 1:2
    if process ==1
        Porosity_range = Porosity_range_1;     
        Fraction_range = Fraction_range_1;          
    elseif process == 2
        Porosity_range = Porosity_range_2;   
        Fraction_range = Fraction_range_2;     
    end
    
    %% -------------------------------------------------------- %%
    % ------------------------ 1-Mineralogy variation  -------------------%
    switch Flag_1

        case 'Variation_between_Clay_Quartz' 
            ii = 1;
            for Fraction_loop = Fraction_range        %   clay content from 20-80%
                                                   % quartz content from 60-00%                                 
                % variation between clay and quartz
                Fraction_Dolomite = frac;           %       dolomite content     %Change
                %Fraction_Kerogen  = 0.1;                                        %Change
                Fraction_Clay     = Fraction_loop;
                Fraction_Quartz   = 1 - Fraction_Dolomite - Fraction_Clay...
                                      - Fraction_Kerogen;

                Fraction_row = [Fraction_Quartz, Fraction_Dolomite,...
                                Fraction_Clay, Fraction_Kerogen,...
                                Fraction_Gas,  Fraction_Oil, Fraction_Water];
                if (sum(Fraction_row(1:(end-3)))-1) > 1e-6 || ...
                   (sum(Fraction_row((end-2):end))-1)
                    error('Minerals/Fliuds fractions should sum up to 1...')
                end
                Fraction_All(ii,:) = Fraction_row;
                
                if process == 2
                   BI_mineralogy(ii,1:1:length(Porosity_range_2)) = ...
                       100*(Fraction_Quartz + Fraction_Dolomite);
                end

                ii = ii + 1;
            end

        case 'Variation_between_Clay_Dolomite' 
            ii = 1;
            for Fraction_loop = Fraction_range      %     clay content from 10-40%

                Fraction_Clay     = Fraction_loop;
                Fraction_Quartz   = frac;
                %Fraction_Kerogen  = 0.1;
                Fraction_Dolomite  = 1 - Fraction_Quartz - Fraction_Clay...
                                      - Fraction_Kerogen;

                Fraction_row = [Fraction_Quartz, Fraction_Dolomite, Fraction_Clay,...
                                Fraction_Kerogen,...
                                Fraction_Gas, Fraction_Oil, Fraction_Water];
                if (sum(Fraction_row(1:(end-3)))-1) > 1e-6 || ...
                   (sum(Fraction_row((end-2):end))-1)
                    error('Minerals/Fliuds fractions should sum up to 1...')
                end
                Fraction_All(ii,:) = Fraction_row;
                
                if process == 2
                   BI_mineralogy(ii,1:1:length(Porosity_range_2)) = ...
                       100*(Fraction_Quartz + Fraction_Dolomite);
                end                    
                
                ii = ii + 1;
            end
    end

%% --------------------------------------------------------------------- %%
% ------------------------  2-four loops for  ----------------------------%
%        ii: laminated clays and kerogen
%        jj: mineralogy variation
%        kk: porosity
%        ll: aspect ratio of pores

    [row, colum] = size(Fraction_All);

    ii = 1;
    for Laminated_loop = 1:1
        Fraction_LaminatedClays   = LaminatedClays_perc;
        Fraction_LaminatedKerogen = LaminatedKerogen_perc;
        for jj = 1:row
            Fraction = Fraction_All(jj,:);
%             Fraction
            kk = 1; 
            for Porosity_loop = Porosity_range
                Porosity = Porosity_loop;
                ll = 1;
                for AspectRatio_loop = AspectRatio_range 
                    Mean_AspectRatio = 10^AspectRatio_loop;  
                   [Cij, ThomsenAniso, Rho] = ...
                        z_ShaleRockPhysics(Fraction,...
                            Fraction_LaminatedClays,Fraction_LaminatedKerogen,...
                            PoreKerogen_perc,...
                            Properties_All,...
                            Porosity,...
                            ThomsenAniso_clay,...
                            Minerals_AspectRatio, Mean_AspectRatio, Num_AspectRatio);

                   ThomsenAniso_ShaleRPT{ii,jj,kk,ll} = ThomsenAniso;  % cell
                            Rho_ShaleRPT(ii,jj,kk,ll) = Rho;
                ll = ll + 1;    
                end
            kk = kk + 1;
            end
        end
    ii = ii + 1;
    end
 
%% --------------------------------------------------------------------- %%
    % ---- extract P- and S-wave velocity from ThomsenAniso_ShaleRPT(ii,jj,kk,ll)
    [row, colum] = size(Fraction_All);
    ii = 1;
    for Laminated_loop = 1:1
        Fraction_LaminatedClays   = LaminatedClays_perc;
        Fraction_LaminatedKerogen = LaminatedKerogen_perc; 
        for jj = 1:row
            Fraction = Fraction_All(jj,:);
            kk = 1; 
            for Porosity_loop = Porosity_range
                Porosity = Porosity_loop;
                ll = 1;
                for AspectRatio_loop = AspectRatio_range 
                    Mean_AspectRatio = 10^AspectRatio_loop;  

                    ShaleRPT_vp(jj,kk)  = ThomsenAniso_ShaleRPT{ii,jj,kk,ll}(1);
                    ShaleRPT_vs(jj,kk)  = ThomsenAniso_ShaleRPT{ii,jj,kk,ll}(2);

                    ShaleRPT_eps(jj,kk)   = ThomsenAniso_ShaleRPT{ii,jj,kk,ll}(3);    
                    ShaleRPT_delt(jj,kk)  = ThomsenAniso_ShaleRPT{ii,jj,kk,ll}(4);                  
                    ShaleRPT_gamma(jj,kk) = ThomsenAniso_ShaleRPT{ii,jj,kk,ll}(5);  

                    ShaleRPT_rho(jj,kk) = Rho_ShaleRPT(ii,jj,kk,ll);            
                ll = ll + 1;
                end
            kk = kk + 1;
            end
        end
    ii = ii + 1;
    end
    
%% --------------------------------------------------------------------- %%
    % ---------------------------    plotting    ---------------------------- %


        % ---- calculate attributes
        ShaleRPT_vp  = ShaleRPT_vp/1000;
        ShaleRPT_vs  = ShaleRPT_vs/1000;
        ShaleRPT_rho = ShaleRPT_rho/1000;
        
        ShaleRPT_Ip       = ShaleRPT_vp.*ShaleRPT_rho;
        ShaleRPT_Is       = ShaleRPT_vs.*ShaleRPT_rho;
        
        ShaleRPT_lamda    = (ShaleRPT_Ip.^2 - 2*ShaleRPT_Is.^2)./ShaleRPT_rho;
        ShaleRPT_mu       = (ShaleRPT_Is.^2)./ShaleRPT_rho;
        
        ShaleRPT_lamdaRho = ShaleRPT_lamda.*ShaleRPT_rho;
        ShaleRPT_muRho    = ShaleRPT_mu.*ShaleRPT_rho;
        
        ShaleRPT_Possion  = ShaleRPT_lamda./(2*(ShaleRPT_lamda + ShaleRPT_mu));
        ShaleRPT_Young    = 2*ShaleRPT_mu.*(1 + ShaleRPT_Possion);
        
    if process == 1
        
       %% ----------------------------------------------------- %%
        % ---- 1 - cross-plotting LamdaRho vs MuRho

        if Flag_2 == 1,
        %figure('color',[1 1 1])
        cla(handles.axes1,'reset');
        axes(handles.axes1);
        [row colum] = size(ShaleRPT_lamdaRho);
        for row_range = 1:colum
            plot(ShaleRPT_lamdaRho(:,row_range),ShaleRPT_muRho(:,row_range),...
             ':k','linewidth',1.5); hold on;
        end
        
        plot(ShaleRPT_lamdaRho(1,:),ShaleRPT_muRho(1,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 0 0]); hold on; 
        plot(ShaleRPT_lamdaRho(2,:),ShaleRPT_muRho(2,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
        plot(ShaleRPT_lamdaRho(3,:),ShaleRPT_muRho(3,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 1 1]); hold on; 
        plot(ShaleRPT_lamdaRho(4,:),ShaleRPT_muRho(4,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 0 1]); hold off; 
        
             hold on;grid on;
             xlabel('\lambda\rho (GPa��g/cm^3)','fontsize',LabelSize);
             ylabel('\mu\rho (GPa��g/cm^3)','fontsize',LabelSize)
             %bookfonts
        
        
        % ---- 2 - cross-plotting Poisson vs Young
        elseif Flag_2 == 2,
        %figure('color',[1 1 1])
        cla(handles.axes1,'reset');
        axes(handles.axes1);
        [row colum] = size(ShaleRPT_Possion);
        for row_range = 1:colum
            plot(ShaleRPT_Possion(:,row_range),ShaleRPT_Young(:,row_range),...
            ':k','linewidth',1.5); hold on;
        end
        
        plot(ShaleRPT_Possion(1,:),ShaleRPT_Young(1,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 0 0]); hold on; 
        plot(ShaleRPT_Possion(2,:),ShaleRPT_Young(2,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
        plot(ShaleRPT_Possion(3,:),ShaleRPT_Young(3,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 1 1]); hold on; 
        plot(ShaleRPT_Possion(4,:),ShaleRPT_Young(4,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 0 1]); hold on; 
        
             hold on;grid on;
             xlabel('\nu','fontsize',LabelSize);
             ylabel('E (GPa)','fontsize',LabelSize)
             %bookfonts
    
        % ---- 3 - cross-plotting Ip vs Vp/Vs
        elseif Flag_2 == 3,
        %figure('color',[1 1 1])
        cla(handles.axes1,'reset');
        axes(handles.axes1);
        [row colum] = size(ShaleRPT_Ip);
        for row_range = 1:colum
            plot(ShaleRPT_Ip(:,row_range),ShaleRPT_vp(:,row_range)./ShaleRPT_vs(:,row_range),...
            ':k','linewidth',1.5); hold on; 
        end
        
        plot(ShaleRPT_Ip(1,:),ShaleRPT_vp(1,:)./ShaleRPT_vs(1,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 0 0]); hold on; 
        plot(ShaleRPT_Ip(2,:),ShaleRPT_vp(2,:)./ShaleRPT_vs(2,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
        plot(ShaleRPT_Ip(3,:),ShaleRPT_vp(3,:)./ShaleRPT_vs(3,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 1 1]); hold on; 
        plot(ShaleRPT_Ip(4,:),ShaleRPT_vp(4,:)./ShaleRPT_vs(4,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 0 1]); hold on; 
        
             grid on;hold on;   
             xlabel('Ip (km/s��g/cm^3)','fontsize',LabelSize);
             ylabel('Vp/Vs','fontsize',LabelSize)
             %bookfonts

        % ---- 4 - cross-plotting Vp vs Vs
        elseif Flag_2 == 4,
        %figure('color',[1 1 1])
        cla(handles.axes1,'reset');
        axes(handles.axes1);
        [row colum] = size(ShaleRPT_Ip);    
        for row_range = 1:colum
            plot(ShaleRPT_vp(:,row_range),ShaleRPT_vs(:,row_range),...
            ':k','linewidth',1.5); hold on; 
        end
        
        plot(ShaleRPT_vp(1,:),ShaleRPT_vs(1,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 0 0]); hold on; 
        plot(ShaleRPT_vp(2,:),ShaleRPT_vs(2,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
        plot(ShaleRPT_vp(3,:),ShaleRPT_vs(3,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 1 1]); hold on; 
        plot(ShaleRPT_vp(4,:),ShaleRPT_vs(4,:),'-ok','linewidth',1.5,...
            'Markersize',11.0,'MarkerFaceColor',[0 0 1]); hold on; 
        
             grid on;hold on;   
             xlabel('Vp (km/s)','fontsize',LabelSize);
             ylabel('Vs (km/s)','fontsize',LabelSize)
             %bookfonts
        end     
             
     elseif process == 2
% 
%        %% ----------------------------------------------------- %%
%         % ---- 1 - plotting anisotropy parameters
%         % Anisotropy parameter: Epsilon
%         figure('color',[1 1 1])
%         plot(Porosity_range,ShaleRPT_eps(1,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[1 0 0]);hold on;
%         plot(Porosity_range,ShaleRPT_eps(2,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]);hold on;     
%         plot(Porosity_range,ShaleRPT_eps(3,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[0 1 1]);hold on;
%         plot(Porosity_range,ShaleRPT_eps(4,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[0 0 1]);hold on;
%         
%              grid on;hold on;
%              title('Anisotropy Parameter \epsilon','fontsize',TitleSize);
%              xlabel('\phi (fraction)','fontsize',LabelSize);
%              ylabel('\epsilon','fontsize',LabelSize)
%              %bookfonts
%              
%         % Anisotropy parameter: Delt
%         figure('color',[1 1 1])
%         plot(Porosity_range,ShaleRPT_delt(1,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[1 0 0]);hold on;
%         plot(Porosity_range,ShaleRPT_delt(2,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]);hold on;     
%         plot(Porosity_range,ShaleRPT_delt(3,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[0 1 1]);hold on;
%         plot(Porosity_range,ShaleRPT_delt(4,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[0 0 1]);hold on;
%         
%              grid on;hold on;
%              title('Anisotropy Parameter \delta','fontsize',TitleSize);
%              xlabel('\phi (fraction)','fontsize',LabelSize);
%              ylabel('\delta','fontsize',LabelSize)
%              %bookfonts             
% 
%         % Anisotropy parameter: Gamma             
%         figure('color',[1 1 1])
%         plot(Porosity_range,ShaleRPT_gamma(1,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[1 0 0]);hold on;
%         plot(Porosity_range,ShaleRPT_gamma(2,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[1 1 0.5]);hold on;     
%         plot(Porosity_range,ShaleRPT_gamma(3,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[0 1 1]);hold on;
%         plot(Porosity_range,ShaleRPT_gamma(4,:),'--ok','linewidth',1.5,...
%             'Markersize',11.0,'MarkerFaceColor',[0 0 1]);hold on;
%         
%              grid on;hold on;
%              title('Anisotropy Parameter \gamma','fontsize',TitleSize);
%              xlabel('\phi (fraction)','fontsize',LabelSize);
%              ylabel('\gamma','fontsize',LabelSize)
%              %bookfonts                 
           
       %% ----------------------------------------------------- %%     
        % ---- 1 - cross-plotting Ip vs Vp/Vs colour-coded by BI
        if Flag_3 == 1,
        %figure('color',[1 1 1])
        cla(handles.axes2,'reset');
        axes(handles.axes2);
        BI = (100*(ShaleRPT_Young-min(min(ShaleRPT_Young)))/(max(max(ShaleRPT_Young))-min(min(ShaleRPT_Young))) ...
            + 100*(ShaleRPT_Possion-max(max(ShaleRPT_Possion)))/(min(min(ShaleRPT_Possion))-max(max(ShaleRPT_Possion))))/2;    
        
        surf(ShaleRPT_Ip,ShaleRPT_vp./ShaleRPT_vs,BI,...
            'FaceColor','interp','EdgeColor','none','FaceLighting','phong');
            view(0,90); box on; colorbar; hold on;
            title({'Crossplot of Ip vs Vp/Vs';'coloured-coded by BI'},'fontsize',10)
            %bookfont(14)
            xlabel('Ip (km/s��g/cm^3)');ylabel('Vp/Vs'); %bookfont(14)
                      
            % ---- overlap sparse points    
            [row colum] = size(ShaleRPT_Ip);    
            
            ShaleRPT_Ip_plot   = ShaleRPT_Ip;
            ShaleRPT_vpvs_plot = ShaleRPT_vp./ShaleRPT_vs;            
            
            for row_range = 1:4:colum
                plot3(ShaleRPT_Ip_plot(1:10:row,row_range),ShaleRPT_vpvs_plot(1:10:row,row_range),9999*ones(4,1),...
                '-k','linewidth',1.0); hold on; 
            end
                     
            plot3(ShaleRPT_Ip_plot(10*0+1,1:4:colum),ShaleRPT_vpvs_plot(10*0+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 0 0]); hold on; 
            plot3(ShaleRPT_Ip_plot(10*1+1,1:4:colum),ShaleRPT_vpvs_plot(10*1+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
            plot3(ShaleRPT_Ip_plot(10*2+1,1:4:colum),ShaleRPT_vpvs_plot(10*2+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 1 1]); hold on; 
            plot3(ShaleRPT_Ip_plot(10*3+1,1:4:colum),ShaleRPT_vpvs_plot(10*3+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 0 1]); hold on;   

       %% ----------------------------------------------------- %%     
        % ---- 2 - cross-plotting Poisson vs Young colour-coded by BI_mineralogy
        elseif Flag_3 == 2,
        %figure('color',[1 1 1])
        cla(handles.axes2,'reset');
        axes(handles.axes2);
        surf(ShaleRPT_Ip,ShaleRPT_vp./ShaleRPT_vs,BI_mineralogy,...
            'FaceColor','interp','EdgeColor','none','FaceLighting','phong');
            view(0,90); box on; colorbar; hold on;
            title({'Crossplot of Ip vs Vp/Vs';'coloured-coded by (quartz + dolomite)%'},'fontsize',10)
            %bookfont(14)
            xlabel('Ip (km/s��g/cm^3)');ylabel('Vp/Vs'); %bookfont(14)
                      
            % ---- overlap sparse points    
            [row colum] = size(ShaleRPT_Ip);    
            
            ShaleRPT_Ip_plot   = ShaleRPT_Ip;
            ShaleRPT_vpvs_plot = ShaleRPT_vp./ShaleRPT_vs;            
            
            for row_range = 1:4:colum
                plot3(ShaleRPT_Ip_plot(1:10:row,row_range),ShaleRPT_vpvs_plot(1:10:row,row_range),9999*ones(4,1),...
                '-k','linewidth',1.0); hold on; 
            end
                     
            plot3(ShaleRPT_Ip_plot(10*0+1,1:4:colum),ShaleRPT_vpvs_plot(10*0+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 0 0]); hold on; 
            plot3(ShaleRPT_Ip_plot(10*1+1,1:4:colum),ShaleRPT_vpvs_plot(10*1+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
            plot3(ShaleRPT_Ip_plot(10*2+1,1:4:colum),ShaleRPT_vpvs_plot(10*2+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 1 1]); hold on; 
            plot3(ShaleRPT_Ip_plot(10*3+1,1:4:colum),ShaleRPT_vpvs_plot(10*3+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 0 1]); hold on;   
          
            
       %% ----------------------------------------------------- %%     
        % ---- 3 - cross-plotting Poisson vs Young colour-coded by BI
        elseif Flag_3 == 3,
        %figure('color',[1 1 1])
        cla(handles.axes2,'reset');
        axes(handles.axes2);
        BI = (100*(ShaleRPT_Young-min(min(ShaleRPT_Young)))/(max(max(ShaleRPT_Young))-min(min(ShaleRPT_Young))) ...
            + 100*(ShaleRPT_Possion-max(max(ShaleRPT_Possion)))/(min(min(ShaleRPT_Possion))-max(max(ShaleRPT_Possion))))/2;    
        
        surf(ShaleRPT_Possion,ShaleRPT_Young,BI,...
            'FaceColor','interp','EdgeColor','none','FaceLighting','phong');
            view(0,90); box on; colorbar; hold on;
            title({'Crossplot of v vs E (GPa)';'coloured-coded by BI'},'fontsize',10)
            %bookfont(14)
            xlabel('v');ylabel('E (GPa)'); %bookfont(14)
                      
            % ---- overlap sparse points    
            [row colum] = size(ShaleRPT_Ip);    
            
            ShaleRPT_Young_plot    =  ShaleRPT_Young;
            ShaleRPT_Possion_plot  =  ShaleRPT_Possion;
            
            for row_range = 1:4:colum
                plot3(ShaleRPT_Possion_plot(1:10:row,row_range),ShaleRPT_Young_plot(1:10:row,row_range),9999*ones(4,1),...
                '-k','linewidth',1.0); hold on; 
            end
                     
            plot3(ShaleRPT_Possion_plot(10*0+1,1:4:colum),ShaleRPT_Young_plot(10*0+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 0 0]); hold on; 
            plot3(ShaleRPT_Possion_plot(10*1+1,1:4:colum),ShaleRPT_Young_plot(10*1+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
            plot3(ShaleRPT_Possion_plot(10*2+1,1:4:colum),ShaleRPT_Young_plot(10*2+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 1 1]); hold on; 
            plot3(ShaleRPT_Possion_plot(10*3+1,1:4:colum),ShaleRPT_Young_plot(10*3+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 0 1]); hold on;   

       %% ----------------------------------------------------- %%     
        % ---- 4 - cross-plotting Poisson vs Young colour-coded by BI_mineralogy
        elseif Flag_3 == 4,
        %figure('color',[1 1 1]) 
        cla(handles.axes2,'reset');
        axes(handles.axes2);
        surf(ShaleRPT_Possion,ShaleRPT_Young,BI_mineralogy,...
            'FaceColor','interp','EdgeColor','none','FaceLighting','phong');
            view(0,90); box on; colorbar; hold on;
            title({'Crossplot of v vs E (GPa)';'coloured-coded by (quartz + dolomite)%'},'fontsize',10)
            %bookfont(14)
            xlabel('v');ylabel('E (GPa)'); %bookfont(14)
                      
            % ---- overlap sparse points    
            [row colum] = size(ShaleRPT_Ip);    
            
            ShaleRPT_Young_plot    =  ShaleRPT_Young;
            ShaleRPT_Possion_plot  =  ShaleRPT_Possion;         
            
            for row_range = 1:4:colum
                plot3(ShaleRPT_Possion_plot(1:10:row,row_range),ShaleRPT_Young_plot(1:10:row,row_range),9999*ones(4,1),...
                '-k','linewidth',1.0); hold on; 
            end
                     
            plot3(ShaleRPT_Possion_plot(10*0+1,1:4:colum),ShaleRPT_Young_plot(10*0+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 0 0]); hold on; 
            plot3(ShaleRPT_Possion_plot(10*1+1,1:4:colum),ShaleRPT_Young_plot(10*1+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[1 1 0.5]); hold on; 
            plot3(ShaleRPT_Possion_plot(10*2+1,1:4:colum),ShaleRPT_Young_plot(10*2+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 1 1]); hold on; 
            plot3(ShaleRPT_Possion_plot(10*3+1,1:4:colum),ShaleRPT_Young_plot(10*3+1,1:4:colum),9999*ones(1,6),'-ok','linewidth',1.0,...
                'Markersize',8.0,'MarkerFaceColor',[0 0 1]); hold on;   
        end                      
            
    end
end


% toc

