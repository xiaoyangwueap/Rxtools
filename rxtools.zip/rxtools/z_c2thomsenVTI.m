function [vp,vs,eps,delt,gamma]=z_c2thomsenVTI(c,r)
% ----------------------------------------------------------------------- %
% function [vp,vs,eps,delt,gamma]=w_c2thomsenVTI(c,r)
% 
% From Cij to Thomsen anisotropy parameters eps, delt, and gamma
% 
% Input:
%   c : 6 by 6 matrix, uint in (Pa)
%   actually used
%   c(1,1) 
%   c(3,3) 
%   c(4,4) 
%   c(6,6) 
%   c(1,3) 
%   r : density, unit in (kg/m3)
% 
% Output:
%     vp, vs, eps, delt, gamma
%     velocity unit in km/s
% 
% Original written by Yungui Xu, modified by Zhiqi Guo on 28 Nov 2011
% ----------------------------------------------------------------------- %

    vp    =  sqrt( c(3,3) / r );
    vs    =  sqrt( c(4,4) / r );
    eps   =  ( c(1,1) - c(3,3)) / (2*c(3,3) );
    delt  =  ((c(1,3) + c(4,4))^2 - (c(3,3) - c(4,4))^2) / (2*c(3,3)*(c(3,3)-c(4,4)));
    gamma =  (c(6,6) - c(4,4)) / (2 * c(4,4));
    