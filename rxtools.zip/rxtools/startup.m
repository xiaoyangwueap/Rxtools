function varargout = startup(varargin)
% STARTUP M-file for startup.fig
%      STARTUP, by itself, creates a new STARTUP or raises the existing
%      singleton*.
%
%      H = STARTUP returns the handle to a new STARTUP or the handle to
%      the existing singleton*.
%
%      STARTUP('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STARTUP.M with the given input arguments.
%
%      STARTUP('Property','Value',...) creates a new STARTUP or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before startup_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to startup_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help startup

% Last Modified by GUIDE v2.5 03-May-2014 16:31:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @startup_OpeningFcn, ...
                   'gui_OutputFcn',  @startup_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before startup is made visible.
function startup_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to rpt
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to startup (see VARARGIN)

% Choose default command line output for startup
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes startup wait for user response (see UIRESUME)
% uiwait(handles.figure1);
s = pwd;
s1 = strcat(s,'\icons\picture1.jpg');
if exist(s1)==0,
    error('File does not exist, please enter rxtools directory!');
else
    G1 = imread(s1);
    axes(handles.axes1);
    image(G1);
    set(handles.axes1,'visible','off')
end

s2 = strcat(s,'\icons\picture2.jpg');
if exist(s2)==0,
    %msgbox('File does not exist, please enter rxtools directory!');
else
    G2 = imread(s2);
    axes(handles.axes2);
    image(G2);
    set(handles.axes2,'visible','off')
end
% s2 = strcat(s,'\icons\picture2.jpg');
% G2 = imread(s2);
% axes(handles.axes2);
% image(G2);
% set(handles.axes2,'visible','off')
s3 = strcat(s,'\icons\picture3.jpg');
if exist(s3)==0,
    %msgbox('File does not exist, please enter rxtools directory!');
else
    G3 = imread(s3);
    axes(handles.axes3);
    image(G3);
    set(handles.axes3,'visible','off')
end

% s3 = strcat(s,'\icons\picture3.jpg');
% G3 = imread(s3);
% axes(handles.axes3);
% image(G3);
% set(handles.axes3,'visible','off')

% h = handles.figure1;
% s4 = strcat(s,'\icons\eaplogo.gif');
% newIcon = javax.swing.ImageIcon(s4);
% figFrame = get(h,'JavaFrame');
% figFrame.setFigureIcon(newIcon);


% --- Outputs from this function are returned to the command line.
function varargout = startup_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to rpt
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function isomdl_Callback(hObject, eventdata, handles)
% hObject    handle to isomdl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function animdl_Callback(hObject, eventdata, handles)
% hObject    handle to animdl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function rc_Callback(hObject, eventdata, handles)
% hObject    handle to rc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function modelling_Callback(hObject, eventdata, handles)
% hObject    handle to modelling (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function inversion_Callback(hObject, eventdata, handles)
% hObject    handle to inversion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function rpt_Callback(hObject, eventdata, handles)
% hObject    handle to rpt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rpt();

% --------------------------------------------------------------------
function vti_Callback(hObject, eventdata, handles)
% hObject    handle to vti (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sp_Callback(hObject, eventdata, handles)
% hObject    handle to sp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vtiavosp();

% --------------------------------------------------------------------
function bka_Callback(hObject, eventdata, handles)
% hObject    handle to bka (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
bkusave();

% --------------------------------------------------------------------
function adem_Callback(hObject, eventdata, handles)
% hObject    handle to adem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
anidem();

% --------------------------------------------------------------------
function hsw_Callback(hObject, eventdata, handles)
% hObject    handle to hsw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function vrh_Callback(hObject, eventdata, handles)
% hObject    handle to vrh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vrh();

% --------------------------------------------------------------------
function dem_Callback(hObject, eventdata, handles)
% hObject    handle to dem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
isodem();

% --------------------------------------------------------------------
function sca_Callback(hObject, eventdata, handles)
% hObject    handle to sca (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
isosca();


% --------------------------------------------------------------------
function ODF_Callback(hObject, eventdata, handles)
% hObject    handle to ODF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
odf();

% --------------------------------------------------------------------
function asca_Callback(hObject, eventdata, handles)
% hObject    handle to asca (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
anisca();

% --------------------------------------------------------------------
function odfshape_Callback(hObject, eventdata, handles)
% hObject    handle to odfshape (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function cd_ani_Callback(hObject, eventdata, handles)
% hObject    handle to cd_ani (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --------------------------------------------------------------------
function iso_Callback(hObject, eventdata, handles)
% hObject    handle to iso (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
isoavo();

% --------------------------------------------------------------------
function hti_Callback(hObject, eventdata, handles)
% hObject    handle to hti (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
htiavosp();

% --------------------------------------------------------------------
function hcrack_Callback(hObject, eventdata, handles)
% hObject    handle to hcrack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hdcrack();


% --------------------------------------------------------------------
function pm_Callback(hObject, eventdata, handles)
% hObject    handle to pm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vtiavopm();
