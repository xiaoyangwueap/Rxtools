%%Compute two-layer model with nonsource shale overlying kerogen shale 
vp1 = 3410;     %unit m/s
vs1 = 1600;     %unit m/s
rho1 = 2550;    %kg/m3
c33 = rho1*vp1*vp1/10^9;
c44 = rho1*vs1*vs1/10^9;
mu1 = c44;
k1 = c33 - 4/3*c44;

vp2 = 3500;     %unit m/s
vs2 = 1630;     %unit m/s
rho2 = 2600;    %kg/m3
c33 = rho2*vp2*vp2/10^9;
c44 = rho2*vs2*vs2/10^9;
mu2 = c44;
k2 = c33 - 4/3*c44;

vp_kerogen = 2250;    %unit m/s
vs_kerogen = 1450;    %unit m/s
rho_kerogen = 1250;   %kg/m3
c33 = rho_kerogen*vp_kerogen*vp_kerogen/10^9;
c44 = rho_kerogen*vs_kerogen*vs_kerogen/10^9;
mu_kerogen = c44;
k_kerogen = c33 - 4/3*c44;

dem(k2,mu2,k_kerogen,mu_kerogen,0.5,1);
xlabel('kerogen content');
ylabel('modulus');
[k,mu,por]=dem(k2,mu2,k_kerogen,mu_kerogen,0.5,1);

x = 0.10;
knew = interp1(por,k,x,'linear');
munew = interp1(por,mu,x,'linear');

%%%%%%%% assume 10% kerogen content; 0.10 crack density
K = knew*10^9; G = munew*10^9;
rho = 2600*(1-x)+1250*x;
[Ctih,den] = hudson(0.10,0.1,1.2*10^9,800,K,G,rho);


%%%%draw figures
% pp0=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp0.dat');
% pp30=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp30.dat');
% pp60=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp60.dat');
% pp90=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp90.dat');
% 
% ppp0=pp0(:,2)+pp0(:,2).*rand(length(pp0(:,2)),1)*0.02;
% ppp30=pp30(:,2)+pp30(:,2).*rand(length(pp30(:,2)),1)*0.02;
% ppp60=pp60(:,2)+pp60(:,2).*rand(length(pp60(:,2)),1)*0.02;
% ppp90=pp90(:,2)+pp90(:,2).*rand(length(pp90(:,2)),1)*0.02;
% 
% ang=1:50;
% figure,plot(ang,pp0(1:50,2),'r');hold on;
% plot(ang,pp30(1:50,2),'g');hold on;
% plot(ang,pp60(1:50,2),'b');hold on;
% plot(ang,pp90(1:50,2),'k');
% legend('0\circ','30\circ','60\circ','90\circ')
% xlabel('angle of incidence');
% ylabel('reflectivity');
% 
% figure,plot(ang,ppp0(1:50),'r');hold on;
% plot(ang,ppp30(1:50),'g');hold on;
% plot(ang,ppp60(1:50),'b');hold on;
% plot(ang,ppp90(1:50),'k');
% legend('0\circ','30\circ','60\circ','90\circ')
% xlabel('angle of incidence');
% ylabel('reflectivity');

