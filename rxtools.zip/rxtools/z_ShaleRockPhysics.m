function [Cij_eff, ThomsenAniso_eff, Rho_eff] = z_ShaleRockPhysics(...
           fraction_all,fra_LaminatedClays,fra_LaminatedKerogen,...
           PoreKerogen_perc,...
           properties_all,...
           porosity,...
           ThomsenAniso_clay,...
           minerals_AspectRatio, mean_AspectRatio,num_AspectRatio)
% ----------------------------------------------------------------------- %
% Shale Rock Physics 
% A shale rock physics model combining SCA with Backus Average
% 
% [Cij, AniCoeff, Rho] = z_ShaleRockPhysics(...
%          fraction_all,fra_LaminatedClays,fra_LaminatedKerogen,...
%          properties_all,...
%          porosity,minerals_AspectRatio, mean_AspectRatio,num_AspectRatio)
% 
% Input:
%     fractioin_all            : fraction of
%     minerals/clay/kerogen/gas/oil/water
%     fra_LaminatedClays       : fraction of laminated clays
%     fra_LaminatedKerogen     : fraction of laminated kerogen
%     PoreKerogen_perc         : fraction of kerogen-related porosity
%     properties_all           : properties of minerals/clay/kerogen/gas/oil/water
%     porosity                 : total porosity
%     mineral_AspectRatio     : aspect ratio of minerals
%     mean_AspectRatio         : means aspect ratio of minerals/pore 
%     num_AspectRatio          : number of pores statistical distribution
% 
%     note :
%     the last five items should be clays/kerogen/gas/oil/water
% 
% Output:
%     Cij      :    stiffness matrix   
%     AniCoeff :    anisotropy parameter epsilon/delt/gamma
%     Rho      :    density of effective medium
% 
% Written by Zhiqi Guo on 18 Nov 2011
% During the period of Marathon Bakken Shale Project
% ----------------------------------------------------------------------- %

%% --------------------------------------------------------------------- %%
% -------- Step 1 of 3: HS bound for laminated clay and kerogen---------- %

% ---- k,mu,rho

 vp_mineral = properties_all(1,1:(end-3));
 vs_mineral = properties_all(2,1:(end-3));
rho_mineral = properties_all(3,1:(end-3));      % minerals

mu_mineral  = rho_mineral.*(vs_mineral.^2);
 k_mineral  = rho_mineral.*(vp_mineral.^2-(4/3)*vs_mineral.^2);
 
 vp_pore    = properties_all(1,(end-2):end);
 vs_pore    = properties_all(2,(end-2):end);
rho_inc     = properties_all(3,(end-2):end);    % gas/oil/water

% ---- Pores 
[k_pore,rho_pore] = wood(rho_inc.*(vp_pore).^2,rho_inc,...
                          fraction_all((end-2):end));
          mu_pore = 0;

  k_pores   =     k_pore*ones(1,num_AspectRatio);
 mu_pores   =    mu_pore*ones(1,num_AspectRatio);  
rho_pores   =   rho_pore*ones(1,num_AspectRatio);  

% ---- Clays with pore 
% ---- modeled by SCA

 vp_clays  =  vp_mineral(end-1);
 vs_clays  =  vs_mineral(end-1);
rho_clays  = rho_mineral(end-1);

  k_clays  = rho_clays*(vp_clays^2-(4/3)*vs_clays^2);
 mu_clays  = rho_clays*vs_clays^2;

 vp_water  =  properties_all(1,end);
 vs_water  =  properties_all(2,end);
rho_water  =  properties_all(3,end);

  k_water  = rho_water*(vp_water^2-(4/3)*vs_water^2);
 mu_water  = rho_water*vs_water^2;

temp_pore = porosity/(1 + porosity);
f   = [1-temp_pore, temp_pore];
k   = [  k_clays,   k_water];
u   = [ mu_clays,  mu_water];
rho = [rho_clays, rho_water]; 

asp = [1 1];
[ka, ua] = berryscm(k,u,asp,f);
rhoa = sum(rho.*f);

k_ClaysWithPore  = ka;
mu_ClaysWithPore = ua;

 vp_ClaysWithPore  = sqrt((ka+(4/3)*ua)/rhoa);
 vs_ClaysWithPore  = sqrt(ua/rhoa);
rho_ClaysWithPore  = rhoa;
    
% ---- Kerogen with pore
% ---- modeled by Carcione's method

 vp_kerogen  =  vp_mineral(end);
 vs_kerogen  =  vs_mineral(end);
rho_kerogen  = rho_mineral(end);

  k_kerogen  = rho_kerogen*(vp_kerogen^2-(4/3)*vs_kerogen^2);
 mu_kerogen  = rho_kerogen*vs_kerogen^2;

s   = (porosity*PoreKerogen_perc)/(fraction_all(end-3) + porosity*PoreKerogen_perc);

c55_KerogenWithPore = mu_kerogen*((1-s)*(9*k_kerogen+8*mu_kerogen)...
                /(9*k_kerogen+8*mu_kerogen+s*(6*k_kerogen+12*mu_kerogen)));
aa = s*(4*mu_kerogen*(k_pore-k_kerogen)/((3*k_pore+4*mu_kerogen)*k_kerogen));
bb = s*(3*(k_pore-k_kerogen)/(3*k_kerogen+4*mu_kerogen));
c13_KerogenWithPore = k_kerogen*(1+aa)/(1-bb) - (2/3)*c55_KerogenWithPore;

 k_KerogenWithPore = c13_KerogenWithPore + 2*c55_KerogenWithPore/3;
mu_KerogenWithPore = c55_KerogenWithPore;

                f   = [1-s, s];
                rho = [rho_kerogen, rho_pore];
rho_KerogenWithPore = sum(rho.*f);

 vp_KerogenWithPore = sqrt((k_KerogenWithPore+(4/3)*mu_KerogenWithPore)/rho_KerogenWithPore);
 vs_KerogenWithPore = sqrt(mu_KerogenWithPore/rho_KerogenWithPore);
 
%% --------------------------------------------------------------------- %%
% ------------------ Step 2 of 3: SCA for mineralogies------------------- %
% 
%              SCA for mineralogies: 
%                   quartz
%                   carbonate 
%                   disoriented clay
%                   pore/cracks with random orientation          

k   = [  k_mineral(1:(end-2)),   k_ClaysWithPore,   k_KerogenWithPore,   k_pores ];
mu  = [ mu_mineral(1:(end-2)),  mu_ClaysWithPore,  mu_KerogenWithPore,  mu_pores ];
rho = [rho_mineral(1:(end-2)), rho_ClaysWithPore, rho_KerogenWithPore, rho_pores ];   
       
% ---- asp: aspect ratio
asp_mineral = minerals_AspectRatio;
asp_mean    = mean_AspectRatio;
asp_std     = 0.1*asp_mean;     % 0.2 or higher results deviation         
asp_pores   = asp_mean + asp_std*randn(1,num_AspectRatio);

      asp   = [asp_mineral  asp_pores ];
            
% ---- x: fraction
      x_mineral  = fraction_all(1:(end-5));    % other minerals than 
                                               % clay/kerogen/gas/oil/water
                                               
      x_clay     = fraction_all(end-4);
      x_kerogen  = fraction_all(end-3);
      
      x = [x_mineral, x_clay, x_kerogen];
            
      if abs(sum(x)-1) > 1e-6
          error('x should sum up to 1')
      end      
      
      x_clay_VTI = x_clay*fra_LaminatedClays;
     x_clay_rand = x_clay - x_clay_VTI;

   x_kerogen_VTI = x_kerogen*fra_LaminatedKerogen;
  x_kerogen_rand = x_kerogen - x_kerogen_VTI;

       x_pores_p =      porosity;     
       
     x_mineral_p =      x_mineral*(1-x_pores_p);   
     
   x_clay_rand_p =    x_clay_rand*(1-x_pores_p);
    x_clay_VTI_p =     x_clay_VTI*(1-x_pores_p);
x_kerogen_rand_p = x_kerogen_rand*(1-x_pores_p);
 x_kerogen_VTI_p =  x_kerogen_VTI*(1-x_pores_p);  
 
       x_p = [x_mineral_p, x_clay_rand_p, x_clay_VTI_p,...
              x_kerogen_rand_p, x_kerogen_VTI_p, x_pores_p];
       
       sum_x_p = sum(x_p);
       
       if abs(sum(x_p)-1) > 1e-6
           error('x_p should sum up to 1');
       end    
      
A = 1-(x_clay_VTI_p + porosity*x_clay*fra_LaminatedClays)-...
      (x_kerogen_VTI_p + porosity*PoreKerogen_perc*fra_LaminatedKerogen);       
       
       x_pore_pp  = porosity*(1 - x_clay - PoreKerogen_perc)/A;
       x_pores_pp = (x_pore_pp/num_AspectRatio)*ones(1,num_AspectRatio);
       
     x_mineral_pp =  x_mineral_p/A;

   x_clay_rand_pp = (x_clay_rand_p + porosity*x_clay*(1-fra_LaminatedClays))/A;
x_kerogen_rand_pp = (x_kerogen_rand_p + porosity*PoreKerogen_perc*(1-fra_LaminatedKerogen))/A;

       x_pp = [x_mineral_pp, x_clay_rand_pp, x_kerogen_rand_pp, x_pores_pp];
% sum_x_pp = sum(x_pp)
       if abs(sum(x_pp)-1) > 1e-6
           error('x_pp should sum up to 1')
       end    
       
       x = x_pp;

% ---- SCA
[k_eff, mu_eff] = berryscm(k,mu,asp,x);

rho_eff = sum(rho.*x);
vp_eff  = sqrt((k_eff+(4/3)*mu_eff)/rho_eff);
vs_eff  = sqrt(mu_eff/rho_eff);

%% --------------------------------------------------------------------- %%
% ------------------- Step 3 of 3: Backus Averaging --------------------- %
%   Backus Average to combine: 
%         mineralogy resulting from SCA
%         LaminatedClays
%         LaminatedKerogen
%         pore/cracks of laterally aligned (if applicable)

    f   = [ (1 - x_clay_VTI - x_kerogen_VTI), x_clay_VTI,...
            x_kerogen_VTI ];
        
    vp  = [  vp_eff,  vp_ClaysWithPore,  vp_KerogenWithPore ]*1e3;
    vs  = [  vs_eff,  vs_ClaysWithPore,  vs_KerogenWithPore ]*1e3;
    den = [ rho_eff, rho_ClaysWithPore, rho_KerogenWithPore ]*1e3;  
    
    eps_clay   = ThomsenAniso_clay(1);    
    delt_clay  = ThomsenAniso_clay(2);  
    gamma_clay = ThomsenAniso_clay(3);  

    eps   = [0,   eps_clay, 0];
    delt  = [0,  delt_clay, 0];
    gamma = [0, gamma_clay, 0];
    
if abs(sum(f)-1) >  1e-6
    error('f must sum up to 1 in bkusc.m')
end

% %---- Backus Average of isotropy version
% [Cij_eff, Rho_eff] = bkusc(f,vp,vs,den);
% [vp,vs,eps,delt,gamma]=z_c2thomsenVTI(Cij_eff,Rho_eff);
% ThomsenAniso_eff = [vp,vs,eps,delt,gamma];

%---- Backus Average of anisotropy version
ThomsenAniso = [vp' vs' eps' delt' gamma'];
[Cij_eff, ThomsenAniso_eff, Rho_eff] = z_backusaverage_carcione(f,ThomsenAniso,den); 





