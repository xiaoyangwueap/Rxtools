% den - bulk density of cracked rock with fluid
% Ctih - C6x6 matrix with symmetry axis along aligned crack normal
%       tih stands for transversely isotropic with a horizontal symmetry axis
%        If inputs are nx1 vectors, Ctih is a 6x6xn array.
% ec - crack density
% ar - aspect ratio of cracks
% Kfl, K: bulk modulus of fluid in cracks, and bulk modulus of isotropic matrix
% rhofl:  density of fluid in cracks
% G: shear modulus of isotropic matrix
% rho: density of matrix
%
% optional input parameter: ax - defines axis of symmetry; ax =1, for crack
% normals aligned along 1-axis (default); ax= 3, for crack normals along
% 3-axis.

%%calculate cij and density for the lower layer
ec = 0.1;
ar = 0.1;
Kfl = 0.0;
rhofl = 0.0;
K = 29.49;
mu = 21.17;
rho = 2.358;
ax = 1;
[Ctih,RHO2]=hudson(ec,ar,Kfl,rhofl,K,mu,rho,ax);  
CC2(1)=Ctih(1,1);
CC2(2)=Ctih(1,3);
CC2(3)=Ctih(3,3);
CC2(4)=Ctih(4,4);
CC2(5)=Ctih(6,6);
%%calculate cij and density for the lower layer


%%specify cij and density for the upper layer
CC1(1)=23.42;
CC1(2)=10.02;
CC1(3)=30.14;
CC1(4)=9.05;
CC1(5)=4.25;
RHO1=2.39;
%%specify cij and density for the upper layer

%%calculate reflectivity
[Rpp1,Rps1,ang]=htischpro(CC1,RHO1,CC2,RHO2,0);
[Rpp2,Rps2,ang]=htischpro(CC1,RHO1,CC2,RHO2,30);
[Rpp3,Rps3,ang]=htischpro(CC1,RHO1,CC2,RHO2,45);
[Rpp4,Rps4,ang]=htischpro(CC1,RHO1,CC2,RHO2,90);

figure, subplot(1,2,1),
plot(ang(1:50),Rpp1(1:50),'r','linewidth',2);hold on;
plot(ang(1:50),Rpp2(1:50),'g','linewidth',2);hold on;
plot(ang(1:50),Rpp3(1:50),'b','linewidth',2);hold on;
plot(ang(1:50),Rpp4(1:50),'k','linewidth',2);
xlim([0 50]);
legend('0^{0}','30^{0}','45^{0}','90^{0}')
xlabel('angle of incidence');
ylabel('Rpp');
grid on;

subplot(1,2,2),
plot(ang(1:50),Rps1(1:50),'r','linewidth',2);hold on;
plot(ang(1:50),Rps2(1:50),'g','linewidth',2);hold on;
plot(ang(1:50),Rps3(1:50),'b','linewidth',2);hold on;
plot(ang(1:50),Rps4(1:50),'k','linewidth',2);
xlim([0 50]);
legend('0^{0}','30^{0}','45^{0}','90^{0}')
xlabel('angle of incidence');
ylabel('Rps');
grid on;