%
% compute the X and Y matrices for anisotropic (monoclinic) media
%
function [s3p,s3s,s3t,np,ns,nt,x,y] = spxymon(s1,s2,tol,rho,c11,c12,c13,c16,c22,c23,c26,c33,c36,c44,c45,c55,c66)
rs3 = zeros(3,1);
is3 = zeros(3,1);
p = zeros(4,1);
s3 = zeros(3,1);
np = zeros(3,1);
ns = zeros(3,1);
nt = zeros(3,1);
x = zeros(3,3);
y = zeros(3,3);
%
s1sqr = s1*s1;
s2sqr = s2*s2;
s12   = s1*s2;
%
% ...............coefficient computation for the Christoffel equations
%
b11 = c55;
b12 = c45;
b22 = c44;
b33 = c33;
%
a11 = c11*s1sqr + c66*s2sqr + 2.*c16*s12 - rho;
a12 = c16*s1sqr + c26*s2sqr + (c12 + c66)*s12;
a13 = (c13 + c55)*s1 + (c36 + c45)*s2;
a22 = c66*s1sqr + c22*s2sqr + 2.*c26*s12 - rho;
a23 = (c36 + c45)*s1 + (c23 + c44)*s2;
a33 = c55*s1sqr + c44*s2sqr + 2.*c45*s12 - rho;
%
p(4) = (b11*b22 - b12*b12)*b33;
%
p(3) = (a11*b22 + b11*a22)*b33 + b11*b22*a33 + 2*a13*a23*b12 ...
        - a13*a13*b22 - a23*a23*b11 - 2*a12*b12*b33 - b12*b12*a33;
%
p(2) = (a11*b22 + b11*a22)*a33 + a11*a22*b33 + 2*a13*a23*a12 ...
       - a13*a13*a22 - a23*a23*a11 - 2*a12*b12*a33 - a12*a12*b33;
%
p(1) = (a11*a22 - a12*a12)*a33;
%
% ...............3-slownesses computations
%
%s3 = rcub(p(4), p(3), p(2), p(1), tol);
s3=roots([p(4), p(3), p(2), p(1)]);
%
% ...............3-slownesses ordering
%
is3(1) = imag(s3(1));
is3(2) = imag(s3(2));
is3(3) = imag(s3(3));
%
if(abs(is3(1)) < tol && abs(is3(2)) < tol && abs(is3(3)) < tol),
%
     rs3(1) = real(s3(1));
     rs3(2) = real(s3(2));
     rs3(3) = real(s3(3));
     rs3 = sort(rs3);

     if(rs3(1) >= 0 && rs3(2) >= 0 && rs3(3) >= 0),
     %type*,'path 1'
         rs3p = sqrt(rs3(1));
         s3p   = rs3p;
         rs3s = sqrt(rs3(2));
         s3s   = rs3s;
         rs3t = sqrt(rs3(3));
         s3t   = rs3t;
%
%................check group velocities for s3q2 and s3q3 signals
%
         [v1, v2, v3] = gvmon(s1, s2, rs3s, rho, c11, c12, c13, c16, c22, c23, c26, c33, c36, c44, c45, c55, c66);
         
         if(v3 < 0), s3s = -s3s; end
         
         [v1, v2, v3] = gvmon(s1, s2, rs3t, rho, c11, c12, c13, c16, c22, c23, c26, c33, c36, c44, c45, c55, c66);
         
         if(v3 < 0), s3t = -s3t; end
         
     elseif (rs3(1) < 0 && rs3(2) >= 0 && rs3(3) >= 0),
%type*,'path 2'
          is3p = sqrt(-rs3(1));
          s3p   = complex(0, is3p);
          rs3s = sqrt(rs3(2));
          s3s   = rs3s;
          rs3t = sqrt(rs3(3));
          s3t   = rs3t;
%
% ...............check group velocities for s3q2 and s3q3 signals
%
         [v1, v2, v3] = gvmon(s1, s2, rs3s, rho, c11, c12, c13, c16, c22, c23, c26, c33, c36, c44, c45, c55, c66);
         
         if(v3 < 0), s3s = -s3s;end
%
         [v1, v2, v3] = gvmon(s1, s2, rs3t, rho, c11, c12, c13, c16, c22, c23, c26, c33, c36, c44, c45, c55, c66);
        
         if(v3 < 0), s3t = -s3t;end

     elseif (rs3(1) < 0 && rs3(2) < 0 && rs3(3) >= 0),
%type*,'path 3'
         is3p = sqrt(-rs3(1));
         s3p   = complex(0, is3p);
         is3s = sqrt(-rs3(2));
         s3s   = complex(0, is3s);
         rs3t = sqrt(rs3(3));
         s3t   = rs3t;
%  
% ...............check group velocities for s3q3 signal
%
         [v1, v2, v3] = gvmon(s1, s2, rs3t, rho, c11, c12, c13, c16, c22, c23, c26, c33, c36, c44, c45, c55, c66);
         if(v3 < 0), s3t = -s3t; end
         
     else
%type*,'path 4'
         is3p = sqrt(-rs3(1));
         s3p   = complex(0, is3p);
         is3s = sqrt(-rs3(2));
         s3s   = complex(0., is3s);
         is3t = sqrt(-rs3(3));
         s3t   = complex(0, is3t);
     end
else
%type*,'path 5'
     s3p = sqrt(s3(1));
     is = abs(imag(s3p));
     s3p = comples(0, is);
     s3s = sqrt(s3(2));
     rs = abs(real(s3s));
     is = abs(imag(s3s));
     s3s = complex(-rs, is);
     s3t = -conj(s3s);
end
%
%
%................the polarization computations
%
%
% ...............p-polarization vector
%
        s3psqr = s3p*s3p;
%
        g11 = a11 + b11*s3psqr;
        g12 = a12 + b12*s3psqr;
        g13 = a13*s3p;
        g22 = a22 + b22*s3psqr;
        g23 = a23*s3p;
        g33 = a33 + b33*s3psqr;
%
        np(1) = g22*g33 - g23*g23;
        np(2) = g13*g23 - g12*g33;
        np(3) = g12*g23 - g13*g22;
%
        nnp = np(1)*conj(np(1)) + np(2)*conj(np(2)) + np(3)*conj(np(3));
%
        if(nnp >= tol), np = npcalculate(np, nnp);
        else
%
           np(1) = g13*g23 - g12*g33;
           np(2) = g11*g33 - g13*g13;
           np(3) = g12*g13 - g23*g11;
%
           nnp = np(1)*conj(np(1)) + np(2)*conj(np(2)) + np(3)*conj(np(3));
%
           if(nnp >= tol), np = npcalculate(np, nnp);
           else
              np(1) = g12*g23 - g13*g22;
              np(2) = g12*g13 - g23*g11;
              np(3) = g11*g22 - g12*g12;
%
              nnp = np(1)*conj(np(1)) + np(2)*conj(np(2)) + np(3)*conj(np(3));
%
              if(nnp >= tol), np = npcalculate(np, nnp);
              else
                 nnp = complex(1,0);
                 np = npcalculate();
              end
           end
        end
%

%
% ...............s-polarization vector
%
        s3ssqr = s3s*s3s;
%
        g11 = a11 + b11*s3ssqr;
        g12 = a12 + b12*s3ssqr;
        g13 = a13*s3s;
        g22 = a22 + b22*s3ssqr;
        g23 = a23*s3s;
        g33 = a33 + b33*s3ssqr;
%
        ns(1) = g22*g33 - g23*g23;
        ns(2) = g13*g23 - g12*g33;
        ns(3) = g12*g23 - g13*g22;
%
        nns = ns(1)*conj(ns(1)) + ns(2)*conj(ns(2)) + ns(3)*conj(ns(3));
%
        if(nns >= tol), ns=nscalculate(ns, nns);
        else
%
           ns(1) = g13*g23 - g12*g33;
           ns(2) = g11*g33 - g13*g13;
           ns(3) = g12*g13 - g23*g11;
%
           nns = ns(1)*conj(ns(1)) + ns(2)*conj(ns(2)) + ns(3)*conj(ns(3));
%
           if(nns >= tol), ns=nscalculate(ns, nns);
           else
              ns(1) = g12*g23 - g13*g22;
              ns(2) = g12*g13 - g23*g11;
              ns(3) = g11*g22 - g12*g12;
%
              nns = ns(1)*conj(ns(1)) + ns(2)*conj(ns(2)) + ns(3)*conj(ns(3));
%
              if(nns >= tol), ns=nscalculate(ns, nns);
              else
                 nns = complex(1,0);
                 ns=nscalculate(ns, nns);
              end
           end
        end

%
% ...............t-polarization vector
%
        s3tsqr = s3t*s3t;
%
        g11 = a11 + b11*s3tsqr;
        g12 = a12 + b12*s3tsqr;
        g13 = a13*s3t;
        g22 = a22 + b22*s3tsqr;
        g23 = a23*s3t;
        g33 = a33 + b33*s3tsqr;
%
        nt(1) = g22*g33 - g23*g23;
        nt(2) = g13*g23 - g12*g33;
        nt(3) = g12*g23 - g13*g22;
%
        nnt = nt(1)*conj(nt(1)) + nt(2)*conj(nt(2)) + nt(3)*conj(nt(3));
%
        if(nnt >= tol), nt=ntcalculate(nt, nnt);
        else
%
           nt(1) = g13*g23 - g12*g33;
           nt(2) = g11*g33 - g13*g13;
           nt(3) = g12*g13 - g23*g11;
%
           nnt = nt(1)*conj(nt(1)) + nt(2)*conj(nt(2)) + nt(3)*conj(nt(3));
%
           if(nnt >= tol), nt=ntcalculate(nt,nnt);
           else
%
              nt(1) = g12*g23 - g13*g22;
              nt(2) = g12*g13 - g23*g11;
              nt(3) = g11*g22 - g12*g12;
%
              nnt = nt(1)*conj(nt(1)) + nt(2)*conj(nt(2)) + nt(3)*conj(nt(3));
%
              if(nnt >= tol), nt=ntcalculate(nt,nnt);
              else
                 
                 nnt = complex(1,0);
                 nt=ntcalculate(nt,nnt);
              end
           end
        end
%

%
%...............X & Y matrices computation
%
        x(1,1) = np(1);
        x(1,2) = ns(1);
        x(1,3) = nt(1);
%
        x(2,1) = np(2);
        x(2,2) = ns(2);
        x(2,3) = nt(2);
%
        x(3,1) = -(c13*np(1) + c36*np(2))*s1 - (c23*np(2) + c36*np(1))*s2 - c33*np(3)*s3p;
        x(3,2) = -(c13*ns(1) + c36*ns(2))*s1 - (c23*ns(2) + c36*ns(1))*s2 - c33*ns(3)*s3s;
        x(3,3) = -(c13*nt(1) + c36*nt(2))*s1 - (c23*nt(2) + c36*nt(1))*s2 - c33*nt(3)*s3t;
% 
        y(1,1) = -(c55*s1 + c45*s2)*np(3) - (c55*np(1) + c45*np(2))*s3p;
        y(1,2) = -(c55*s1 + c45*s2)*ns(3) - (c55*ns(1) + c45*ns(2))*s3s;
        y(1,3) = -(c55*s1 + c45*s2)*nt(3) - (c55*nt(1) + c45*nt(2))*s3t;
%
        y(2,1) = -(c45*s1 + c44*s2)*np(3) - (c45*np(1) + c44*np(2))*s3p;
        y(2,2) = -(c45*s1 + c44*s2)*ns(3) - (c45*ns(1) + c44*ns(2))*s3s;
        y(2,3) = -(c45*s1 + c44*s2)*nt(3) - (c45*nt(1) + c44*nt(2))*s3t;
%
        y(3,1) = np(3);
        y(3,2) = ns(3);
        y(3,3) = nt(3);
%


function np = npcalculate(np0, nnp)
         nnp = sqrt(nnp);        %%%%%%%%%%%%%%10
%
        np0(1) = np0(1) / nnp;
        np0(2) = np0(2) / nnp;
        np0(3) = np0(3) / nnp;
% 
        np = standvec(np0);
        
        
function ns = nscalculate(ns0, nns)
        nns = sqrt(nns);         %%%%%%%%%%%%%20
%
        ns0(1) = ns0(1) / nns;
        ns0(2) = ns0(2) / nns;
        ns0(3) = ns0(3) / nns;
% 
        ns = standvec(ns0);
        
function nt = ntcalculate(nt0, nnt)
        nnt = sqrt(nnt);        %%%%%%%%%%%%%%30
%
        nt0(1) = nt0(1) / nnt;
        nt0(2) = nt0(2) / nnt;
        nt0(3) = nt0(3) / nnt;
% 
        nt = standvec(nt0);

function n = standvec(n0)
        n = zeros(3,1);
        ur = zeros(3,1);
        ui = zeros(3,1);

        for i = 1:3,
           ur(i) = real(n0(i));
           ui(i) = imag(n0(i));
        end

        urur = 0.;
        uiui = 0.;
        urui = 0.;

        for i=1:3,
           urur = urur + ur(i)*ur(i);
           uiui = uiui + ui(i)*ui(i);
           urui = urui + ur(i)*ui(i);
        end

        gama = atan(2*urui/(urur - uiui));
        phase = exp(complex(0.,-2*gama));

        for i=1:3,
           n(i) = phase*n0(i);
        end

        for i = 1:3,
           ur(i) = real(n(i));
           ui(i) = imag(n(i));
        end

        uiui = 0.;
        urur = 0.;
        
        for i=1:3,
           urur = urur + ur(i)*ur(i);
           uiui = uiui + ui(i)*ui(i);
        end
        
        if(uiui > urur),
           for i=1:3,
               n(i) = complex(-ui(i),ur(i));
           end
        end
%
% compute the group velocities of monoclinic media
%
function[v1, v2, v3] = gvmon(s1, s2, s3, rho, c11, c12, c13, c16, c22, c23, c26, c33, c36, c44, c45, c55, c66)
%local variables
c2=zeros(6,6);
sn=zeros(3,1);
vg=zeros(3,1);
%integer i,j,ifail
     sn(1) = s1;
     sn(2) = s2;
     sn(3) = s3;

     for j = 1:6
         for i = 1:6
             c2(i,j) = 0.;
        end
     end

    c2(1,1) = c11;
	c2(1,2) = c12;
	c2(1,3) = c13;
    c2(1,6) = c16;
	c2(2,2) = c22;
	c2(2,3) = c23;
	c2(2,6) = c26;
	c2(3,3) = c33;
	c2(3,6) = c36;
	c2(4,4) = c44;
	c2(4,5) = c45;
	c2(5,5) = c55;
	c2(6,6) = c66;
%
        vg = dgrpvel (c2,rho,sn,0);

        v1 = vg(1);
        v2 = vg(2);
        v3 = vg(3);
%


function vg = dgrpvel(c2,rho,sn,ifail)
% c2 = zeros(6,6);
% sn = zeros(3,1);
vg = zeros(3,1);
%integer  ifail

c4 = zeros(3,3,3,3);
f = zeros(3,3);
df = zeros(3,3,3);
cf = zeros(3,3);
dfd = zeros(3,1);

%integer  i,j,k,l
%real *8  denom

% Helbig (1994) 'Foundations of Anisotropy for Exploration Seismics'

% Calculate the group velocity vector corresponding to a slowness vector

% c2(,):	DR 	stiffness tensor
% rho:		DR	density
%c sn():		DR	slowness vector
%c vg():		DR 	ray velocity vector
%c ifail:      	I	0=sucess, 1=division by zero

ifail = 0;
[c4,c2]=dstiffness(c4,c2,4,ifail);

      for i=1:3,
          for k=1:3,
              f(i,k)=0;
              for j=1:3,
                  for l=1:3,
                  f(i,k) = f(i,k) + c4(i,j,k,l)*sn(j)*sn(l);
                  end
              end
              if(i == k),
                  f(i,k) = f(i,k)-rho;
              end
          end
      end
 
      cf(1,1) = f(2,2)*f(3,3) - f(2,3)^2;		%signed cofactors
      cf(2,2) = f(1,1)*f(3,3) - f(1,3)^2;		%of f(i,k)
      cf(3,3) = f(1,1)*f(2,2) - f(1,2)^2;

      cf(1,2) = f(2,3)*f(3,1) - f(2,1)*f(3,3);
      cf(2,1) = cf(1,2);

      cf(2,3) = f(3,1)*f(1,2) - f(3,2)*f(1,1);		%n.b. error in
      cf(3,2) = cf(2,3);					        %Helbig 1995

      cf(3,1) = f(1,2)*f(2,3) - f(1,3)*f(2,2);
      cf(1,3) = cf(3,1);

      for i=1:3,						    % derivatives of 
          for j=1:3,						% determinant elements
              for k=1:3,
                  df(i,j,k) = 0;
                  for l=1:3,
                      df(i,j,k) = df(i,j,k) + (c4(i,j,k,l) + c4(k,j,i,l))*sn(l);
                  end
              end
          end 
      end
      
      for k=1:3,						%gradient components
          dfd(k) = 0;
          for i=1:3,
              for j=1:3,
                  dfd(k) = dfd(k) + df(i,j,k)*cf(i,j);
              end
          end
      end

      denom=0;						   %normalise to get
      
      for i=1:3,						   %group velocity
          denom = denom + sn(i)*dfd(i);
      end

      if(denom == 0),
         ifail = 1;
         return;
      end

      for i=1:3,
          vg(i) = dfd(i)/denom;
      end



%---------------------------------------------------------------
function [a4, b2] = dstiffness (a4, b2, mode, err)
%
% convert stiffnesses and compliances between notations
%
% a4: matrix in 4-subscript notation
% b2: matrix in 2-subscript notation
%
% in four lines below the following information is given
% "type of tensor, number of subscripts (out) <- (in)"
%
% mode=1: compliance, 2<-4
% mode=2: stiffness,  2<-4
% mode=3, compliance, 4<-2
% mode=4: stiffness,  4<-2
%
% err=16: undefined mode
%
% ---------- from Helbig (1994), pp.123-124.
%
      %a4 = zeros(3,3,3,3);
      %b2 = zeros(6,6);
% integer i,j,k,l,p,q,mode,err
%
      err = 0;
% block off calls with non-existing code
      if(mode < 1 && mode > 4),
         err = 16;
         return;
      end
%
% set subscript exchange and factors
%
      for i=1:3,
          for j=1:3,
             if(i == j),
                p=i;
                f1=1.;
             else
                p=9-i-j;
                f1=2.;
             end
             for k=1:3,
                for l=1:3,
                  if(k == l),
                    q=k;
                    f2=1.;
                  else
                    q=9-k-l;
                    f2=2.;
                  end
                  if(mode == 4),
                     a4(i,j,k,l) = b2(p,q);
                  elseif(mode == 3),
                     a4(i,j,k,l) = b2(p,q)/f1/f2;
                  elseif(mode == 2),
                     b2(p,q) = a4(i,j,k,l);
                  else
                     b2(p,q) = a4(i,j,k,l)*f1*f2;
                  end
               end
            end
         end
      end