%Compute two-layer model with nonsource shale overlying kerogen shale
x = 0.01:0.01:0.30;
mu = 0.15;sigma = 0.08;
y1 = 1/(sqrt(2*pi)*sigma).*exp(-(x-mu).^2./(2*sigma^2));
y1 = y1/sum(y1);
subplot(2,1,1);plot(x,y1);
xlim([0,0.3]);
xlabel('kerogen content');
ylabel('pdf');

x = 0.01:0.01:0.20;
mu = 0.08;sigma = 0.03;
y2 = 1/(sqrt(2*pi)*sigma).*exp(-(x-mu).^2./(2*sigma^2));
y2 = y2/sum(y2);
subplot(2,1,2);plot(x,y2);
xlim([0,0.20]);
xlabel('fracture density');
ylabel('pdf');

%%%%%%%prior information%%%%%%%%
prior = y1'*y2;
prior = prior/sum(sum(prior));
figure,imagesc(0.01:0.01:0.2,0.01:0.01:0.3,prior),colorbar();
xlabel('fracture density');
ylabel('kerogen content');




vp1 = 3410;     %unit m/s
vs1 = 1640;     %unit m/s
rho1 = 2550;    %kg/m3
c33 = rho1*vp1*vp1/10^9;
c44 = rho1*vs1*vs1/10^9;
mu1 = c44;
k1 = c33 - 4/3*c44;

vp2 = 3500;     %unit m/s
vs2 = 1630;     %unit m/s
rho2 = 2600;    %kg/m3
c33 = rho2*vp2*vp2/10^9;
c44 = rho2*vs2*vs2/10^9;
mu2 = c44;
k2 = c33 - 4/3*c44;

vp_kerogen = 2250;    %unit m/s
vs_kerogen = 1450;    %unit m/s
rho_kerogen = 1250;   %kg/m3
c33 = rho_kerogen*vp_kerogen*vp_kerogen/10^9;
c44 = rho_kerogen*vs_kerogen*vs_kerogen/10^9;
mu_kerogen = c44;
k_kerogen = c33 - 4/3*c44;

dem(k2,mu2,k_kerogen,mu_kerogen,0.5,1);
[k,mu,por]=dem(k2,mu2,k_kerogen,mu_kerogen,0.5,1);


%%%%%%%%%% assume 5% kerogen content; 0.1 crack density
x = 0:0.01:0.29;
knew = interp1(por,k,x,'linear')*10^9;
munew = interp1(por,mu,x,'linear')*10^9;
rho=2600*(1-x) + 1250*x;
ar(1:30)=0.1; Kfl(1:30)=1.2*10^9;rhofl(1:30)=800;
ec=zeros(30,20);
CC=zeros(6,6,30,20);
for i = 1:20
    ec(:,i) = (i-1)*0.01;
    [Ctih,den] = hudson(ec(:,i)',ar,Kfl,rhofl,knew,munew,rho);
    CC(:,:,:,i)=Ctih;
end

for i=1:20
    for j=1:30
        for k=1:6
            for l=1:6
                ck(l+(k-1)*6,j,i)=CC(l,k,j,i);
            end
        end
    end
end

% GrdFile='Z:\aniseis\fdep\anireflect\shalegas\multi\datam.dat';
% [fidGrd,msg] = fopen(GrdFile,'wt');
% format short e
% for i=1:20
%     for j=1:30
%         for k=1:36
%             fprintf(fidGrd,'   %f',ck(k,j,i));
%         end
%         %fprintf(fidGrd,'\n');
%     end
% end
% format
% fclose(fidGrd);





