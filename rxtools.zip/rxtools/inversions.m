m1 = load('Z:\aniseis\fdep\anireflect\shalegas\multi\pp0m.dat');
m2 = load('Z:\aniseis\fdep\anireflect\shalegas\multi\pp30m.dat');
m3 = load('Z:\aniseis\fdep\anireflect\shalegas\multi\pp60m.dat');
m4 = load('Z:\aniseis\fdep\anireflect\shalegas\multi\pp90m.dat');

pp0=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp0.dat');
pp30=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp30.dat');
pp60=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp60.dat');
pp90=load('Z:\aniseis\fdep\anireflect\shalegas\single\pp90.dat');

ppp0=pp0(1:50,2)+pp0(1:50,2).*rand(50,1)*0.02;ppp0=ppp0';
ppp30=pp30(1:50,2)+pp30(1:50,2).*rand(50,1)*0.02;ppp30=ppp30';
ppp60=pp60(1:50,2)+pp60(1:50,2).*rand(50,1)*0.02;ppp60=ppp60';
ppp90=pp90(1:50,2)+pp90(1:50,2).*rand(50,1)*0.02;ppp90=ppp90';

% ppp0=pp0(1:40,2);ppp0=ppp0';
% ppp30=pp30(1:40,2);ppp30=ppp30';
% ppp60=pp60(1:40,2);ppp60=ppp60';
% ppp90=pp90(1:40,2);ppp90=ppp90';

error=zeros(30,20);
for i=1:20,
    frac=i*0.01;
    for j=1:30,
        kerogen=j*0.01;
        z1=m1((i-1)*30+j,:);
        z2=m2((i-1)*30+j,:);
        z3=m3((i-1)*30+j,:);
        z4=m4((i-1)*30+j,:);
        error(j,i)=sum(sum(abs(z1-ppp0))+sum(abs(z2-ppp30))+sum(abs(z3-ppp60))+sum(abs(z4-ppp90)));
    end
end
figure,imagesc(0.01:0.01:0.2,0.00:0.01:0.29,error);colorbar();
xlabel('fracture density');
ylabel('kerogen content');

s = 1.0;
likelyhood = exp(-s*error);
figure,imagesc(0.01:0.01:0.2,0.00:0.01:0.29,likelyhood);colorbar();
xlabel('fracture density');
ylabel('kerogen content');

%%%%%%%%%%%%%%%%prior information%%%%%%%%%%%%%%
x = 0.0:0.01:0.30;
mu = 0.15;sigma = 0.08;
y1 = 1/(sqrt(2*pi)*sigma).*exp(-(x-mu).^2./(2*sigma^2));
y1 = y1/sum(y1);
figure,subplot(2,1,1);plot(x,y1);
xlim([0,0.3]);
xlabel('kerogen content');
ylabel('pdf');

x = 0.0:0.01:0.20;
mu = 0.06;sigma = 0.03;
y2 = 1/(sqrt(2*pi)*sigma).*exp(-(x-mu).^2./(2*sigma^2));
y2 = y2/sum(y2);
subplot(2,1,2);plot(x,y2);
xlim([0,0.20]);
xlabel('fracture density');
ylabel('pdf');

prior = y1'*y2;
prior = prior/sum(sum(prior));
figure,imagesc(0.01:0.01:0.2,0.01:0.01:0.3,prior),colorbar();
xlabel('fracture density');
ylabel('kerogen content');

x = 0.01:0.01:0.30;
mu = 0.15;sigma = 0.08;
y1 = 1/(sqrt(2*pi)*sigma).*exp(-(x-mu).^2./(2*sigma^2));
y1 = y1/sum(y1);


x = 0.01:0.01:0.20;
mu = 0.06;sigma = 0.03;
y2 = 1/(sqrt(2*pi)*sigma).*exp(-(x-mu).^2./(2*sigma^2));
y2 = y2/sum(y2);


prior = y1'*y2;
prior = prior/sum(sum(prior));
figure,imagesc(0.01:0.01:0.2,0.01:0.01:0.3,prior),colorbar();
xlabel('fracture density');
ylabel('kerogen content');

%%%%%%%posterior information%%%%%%%%
posterior = prior.*likelyhood;
figure,imagesc(0.01:0.01:0.2,0.00:0.01:0.29,posterior),colorbar();
xlabel('fracture density');
ylabel('kerogen content');

