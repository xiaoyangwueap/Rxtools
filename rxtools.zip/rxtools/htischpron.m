function [Rpp,Rps,Rpt,Rsp,Rss,Rst,Rtp,Rts,Rtt,ang] = htischpron(CC1,RHO1,CC2,RHO2,phi,angle)
%C111=46.03; C221=46.03; C331=33.52; C121=11.35; C131=9.90; C231=9.90; C441=9.05; C551=9.05; C661=17.34;
%C112=23.474; C222=23.474; C332=16.767; C122=7.522; C132=8.062; C232=8.062; C442=5.698; C552=5.698; C662=7.976;
%RHO1=2.39; RHO2=2.3; %%Input VTI shale model
C111 = CC1(1); C121 = CC1(2); C131 = C121; C331 = CC1(3);
C221 = C331; C161 = 0; C261 = 0; C361 = 0;
C441 = CC1(4); C451=0; C661 = CC1(5); C551 = C661;
C231 = C331-2*C441;

if angle==0,
    C112 = CC2(1); C122 = CC2(2); C132 = C122; C332 = CC2(3);
    C222 = C332; C162 = 0; C262 = 0; C362 = 0;
    C442 = CC2(4); C452=0; C662 = CC2(5); C552 = C662;
    C232 = C332-2*C442;  
elseif angle~=0,
    C112 = CC2(1); C122 = CC2(2); C332 = CC2(3);
    C442 = CC2(4); C662 = CC2(5);
    C232 = C332-2*C442;
    c = [C112,C122,C122,0,0,0;
         C122,C332,C232,0,0,0;
         C122,C232,C332,0,0,0;
         0,0,0,C442,0,0;
         0,0,0,0,C662,0;
         0,0,0,0,0,C662];
[cnew, M] = ezbond(c, angle);
    C112 = cnew(1,1);
    C132 = cnew(1,3);
    C122 = cnew(1,2);
    C332 = cnew(3,3);
    C222 = cnew(2,2);
    C162 = cnew(1,6);
    C262 = cnew(2,6);
    C362 = cnew(3,6);
    C442 = cnew(4,4);
    C452 = cnew(4,5);
    C662 = cnew(6,6);
    C552 = cnew(5,5);
    C232 = cnew(2,3);
end

S1p = zeros(90,1); S2p=zeros(90,1); S3p=zeros(90,1);
S1s = zeros(90,1); S2s=zeros(90,1); S3s=zeros(90,1);
S1t = zeros(90,1); S2t=zeros(90,1); S3t=zeros(90,1);
V1p = zeros(90,1); V2p=zeros(90,1); V3p=zeros(90,1);
V1s = zeros(90,1); V2s=zeros(90,1); V3s=zeros(90,1);
V1t = zeros(90,1); V2t=zeros(90,1); V3t=zeros(90,1);
%
X1=zeros(3,3); Y1=zeros(3,3);
X2=zeros(3,3); Y2=zeros(3,3);
R=zeros(3,3); T=zeros(3,3);
Rpp=zeros(91,1); Rps=zeros(91,1); Rpt=zeros(91,1);
Rsp=zeros(91,1); Rss=zeros(91,1); Rst=zeros(91,1);
Rtp=zeros(91,1); Rts=zeros(91,1); Rtt=zeros(91,1);
Tpp=zeros(91,1); Tps=zeros(91,1); Tpt=zeros(91,1);
Tsp=zeros(91,1); Tss=zeros(91,1); Tst=zeros(91,1);
Ttp=zeros(91,1); Tts=zeros(91,1); Ttt=zeros(91,1);
%
for i=1:91,
    theta=i-1;
    n1=cos(pi*phi/180)*sin(pi*theta/180);
    n2=sin(pi*phi/180)*sin(pi*theta/180);
    n3=cos(pi*theta/180);
    x1=(C111*n1^2+C661*n2^2+C551*n3^2)/RHO1;
    x2=(C661*n1^2+C221*n2^2+C441*n3^2)/RHO1;
    x3=(C551*n1^2+C441*n2^2+C331*n3^2)/RHO1;
    x4=(C121+C661)*n1*n2/RHO1;
    x5=(C131+C551)*n1*n3/RHO1;
    x6=(C231+C441)*n2*n3/RHO1;
    S = [x1 x4 x5; x4 x2 x6; x5 x6 x3];
    [V,D]=eig(S);
    if (D(1,1)>=D(2,2)>=D(3,3))||(D(1,1)>=D(3,3)>=D(2,2)),
    A(1)=1/D(1,1);
    else if (D(2,2)>=D(1,1)>=D(3,3))||(D(2,2)>=D(3,3)>=D(1,1)),
            A(1)=1/D(2,2);
        else A(1)=1/D(3,3);
        end
    end
    S1(i,1) = sqrt(A(1))*n1;
    S2(i,1) = sqrt(A(1))*n2;
    [s3p,s3s,s3t,np,ns,nt,X1,Y1] = spxymon(S1(i,1),S2(i,1),1e-6,RHO1,C111,C121,C131,C161,C221,C231,C261,C331,C361,C441,C451,C551,C661);
    [s3p,s3s,s3t,np,ns,nt,X2,Y2] = spxymon(S1(i,1),S2(i,1),1e-6,RHO2,C112,C122,C132,C162,C222,C232,C262,C332,C362,C442,C452,C552,C662);

    I1=eye(3);
    if (cond(Y1)>1e19),
        R=(X1\X2*Y2\Y1-I1)/(X1\X2*Y2\Y1+I1);
    elseif(cond(X1)>1e19),
        R=(I1+Y1\Y2*X2\X1)/(I1-Y1\Y2*X2\X1);
    else
        R = (X1\X2-Y1\Y2)/(X1\X2+Y1\Y2);
        T = 2./(X1\X2+Y1\Y2);
   end
    
    Rpp(i,1) = R(1,1); Rps(i,1) = R(2,1); Rpt(i,1) = R(3,1);
    Rsp(i,1) = R(1,2); Rss(i,1) = R(2,2); Rst(i,1) = R(3,2);
    Rtp(i,1) = R(1,3); Rts(i,1) = R(2,3); Rtt(i,1) = R(3,3);
    Tpp(i,1) = T(1,1); Tps(i,1) = T(2,1); Tpt(i,1) = T(3,1);
    Tsp(i,1) = T(1,2); Tss(i,1) = T(2,2); Tst(i,1) = T(3,2);
    Ttp(i,1) = T(1,3); Tts(i,1) = T(2,3); Ttt(i,1) = T(3,3);
end

% Rpp(1,1)=(sqrt(RHO2*C332)-sqrt(RHO1*C331))/(sqrt(RHO2*C332)+sqrt(RHO1*C331));
% Rss(1,1)=(sqrt(RHO2*C662)-sqrt(RHO1*C661))/(sqrt(RHO2*C662)+sqrt(RHO1*C661));
% Rtt(1,1)=(sqrt(RHO2*C442)-sqrt(RHO1*C441))/(sqrt(RHO2*C442)+sqrt(RHO1*C441));

ang=0:1:90;

