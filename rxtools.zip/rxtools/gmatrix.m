function g=gmatrix(c11,c12,c13,c33,c44,asp)
%calculate the G matrix
g = zeros(6);
S = [0 0 0 0 0 0 0];
if c44==0,
   c44=0.01;
   c12=c11-2*c44;
end

[S(1),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,1),0,1,1e-2);
[S(2),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,2),0,1,1e-2);
[S(3),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,3),0,1,1e-2);
[S(4),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,4),0,1,1e-2);
[S(5),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,5),0,1,1e-2);
[S(6),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,6),0,1,1e-2);
[S(7),n] = quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,7),0,1,1e-2);
% ak = isfinite(S);
% for i = 1:7
%     if ak(i)==0,S(i)=0;end
% end
    
% [S(1),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,1),1e-6,1-1e-6,1e-6);
% [S(2),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,2),1e-6,1-1e-6,1e-6);
% [S(3),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,3),1e-6,1-1e-6,1e-6);
% [S(4),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,4),1e-6,1-1e-6,1e-6);
% [S(5),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,5),1e-6,1-1e-6,1e-6);
% [S(6),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,6),1e-6,1-1e-6,1e-6);
% [S(7),n]=quadl(@(x)fint(x,c11,c12,c13,c33,c44,asp,7),1e-6,1-1e-6,1e-6);

g1111=S(1);g2222=S(1);
g3333=S(2);
g1122=S(3);g2211=S(3);
g1133=S(4);g2233=S(4);
g3311=S(5);g3322=S(5);
g1212=S(6);
g1313=S(7);g2323=S(7);

G1111=(g1111+g1111)/(8*pi);
G1122=(g1212+g1212)/(8*pi);   %Gijkl=1/(8*pi)*(gikjl+gjkil)
G1133=(g1313+g1313)/(8*pi);
G2222=(g2222+g2222)/(8*pi);
G3311=(g1313+g1313)/(8*pi);
G3333=(g3333+g3333)/(8*pi);
G1313=(g1133+g1313)/(8*pi);
G1212=(g1122+g1212)/(8*pi);

g=[G1111 G1122 G1133 0 0 0;
   G1122 G2222 G1133 0 0 0;
   G3311 G3311 G3333 0 0 0;
   0 0 0 2*G1313 0 0;
   0 0 0 0 2*G1313 0;
   0 0 0 0 0 2*G1212;];
