%Calculates the stffness tensor components for shale and kerogen layers,
%assuming each layer is isotropic, using P & S velocities. Kergoen layers
%are assumed isotropic; shale layers are assumed transversely isotropic.

function [Ys, Yk] = bkvel2ten(Vps90, Vps0, Vss90, Vss0, delta, Vpk, Vsk, rhos, rhok)

%Vps90 = Normal P-wave velocity, shale
%Vps0 = Parallel P-wave velocity, shale
%Vss90 = Normal S-wave velocity, shale
%Vss0 = Parallel S-wave velocity, shale
%Vpk = P-wave velocity in kerogen
%Vsk = S-wave velocity in kerogen
%rhos = density of shale
%rhok = density of kerogen
%delta = delta anisotropy parameter


%Shale coefficients. Expressions from Rock Physics Handbook P. 29

c11 = rhos*(Vps90^2);
c12 = c11 - 2*rhos*(Vss90^2);

c33 = rhos*(Vps0^2);
c44 = rhos*(Vss0^2);
c66 = 0.5*(c11 - c12);
c13 = (delta*2*c33*(c33-c44)+(c33-c44)^2)^0.5-c44;  %from Thomsen 1986

%Kerogen coefficients. Expressions from Rock Physics Handbook P.26&28

d11 = rhok*(Vpk^2);
d44 = rhok*(Vsk^2);
d12 = d11 - 2*d44;
d13 = d12;
d33 = d11;
d66 = d44;

Ys = [c11, c12, c13, 0, 0, 0;
    c12, c11, c13, 0, 0, 0;
    c13, c13, c33, 0, 0, 0;
    0, 0, 0, c44, 0, 0;
    0, 0, 0, 0, c44, 0;
    0, 0, 0, 0, 0, c66];

Yk = [d11, d12, d12, 0, 0, 0;
    d12, d11, d12, 0, 0, 0;
    d12, d12, d11, 0, 0, 0;
    0, 0, 0, d44, 0, 0;
    0, 0, 0, 0, d44, 0;
    0, 0, 0, 0, 0, d44];
