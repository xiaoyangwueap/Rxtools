function [cort, cl] = vti2ort(cvti,dn,dv,dh)
%calculte the cij of orthorambic media from vti media with vertical
%fractures using the method of Schoemberg and Sayers(1995). 
%dn,dv,dh must be values between [0,1).

%example:
%cvti = [10 4 2.5 0 0 0;
%     4 10 2.5 0 0 0;
%     2.5 2.5 6 0 0 0;
%     0 0 0 2 0 0;
%     0 0 0 0 2 0;
%     0 0 0 0 0 3];
% dn = 1/10;dv=1/5;dh=3/11;
% cort=vti2ort(cvti,dn,dv,dh);

cort = zeros(6,6);
cort(1,1) = cvti(1,1)*(1-dn);
cort(1,2) = cvti(1,2)*(1-dn);
cort(1,3) = cvti(1,3)*(1-dn);

cort(2,1) = cvti(1,2)*(1-dn);
cort(2,2) = cvti(1,1)*(1-dn*cvti(1,2)^2/cvti(1,1)^2);
cort(2,3) = cvti(1,3)*(1-dn*cvti(1,2)/cvti(1,1));

cort(3,1) = cvti(1,3)*(1-dn);
cort(3,2) = cvti(1,3)*(1-dn*cvti(1,2)/cvti(1,1));
cort(3,3) = cvti(3,3)*(1-dn*(cvti(1,3)^2/(cvti(1,1)*cvti(3,3))));

cort(4,4)=cvti(4,4);
cort(5,5)=cvti(4,4)*(1-dv);
cort(6,6)=cvti(6,6)*(1-dh);

cl=[cort(1,1) cort(2,2) cort(3,3) cort(4,4) cort(5,5) cort(6,6) cort(1,2) cort(1,3) cort(2,3)];

% cvti = [23.47 7.51 8.06 0 0 0;
%          7.51 23.47 8.06  0 0 0;
%          8.06 8.06 16.77 0 0 0;
%          0 0 0 5.70 0 0;
%          0 0 0 0 5.70 0;
%          0 0 0 0 0 7.98];


