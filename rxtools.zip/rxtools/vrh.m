function varargout = vrh(varargin)
% VRH MATLAB code for vrh.fig
%      VRH, by itself, creates a new VRH or raises the existing
%      singleton*.
%
%      H = VRH returns the handle to a new VRH or the handle to
%      the existing singleton*.
%
%      VRH('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VRH.M with the given input arguments.
%
%      VRH('Property','Value',...) creates a new VRH or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before vrh_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to vrh_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help vrh

% Last Modified by GUIDE v2.5 09-Jul-2014 14:47:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @vrh_OpeningFcn, ...
                   'gui_OutputFcn',  @vrh_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before vrh is made visible.
function vrh_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to vrh (see VARARGIN)

% Choose default command line output for vrh
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes vrh wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = vrh_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
vol_calcite = floor(get(handles.slider3,'Value'));
set(hObject,'Max',100-vol_calcite);
set(handles.slider2,'Max',100-vol_calcite);
vol_clay = floor(get(hObject,'Value'));
vol_quartz=100-vol_calcite-vol_clay;
set(handles.edit1,'String',num2str(vol_clay));
set(handles.edit2,'String',num2str(vol_quartz));
set(handles.slider2,'Value',vol_quartz);

calculate_vrh(handles);
% draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
vol_calcite = floor(get(handles.slider3,'Value'));
set(hObject,'Max',100-vol_calcite);
set(handles.slider1,'Max',100-vol_calcite);
vol_quartz = floor(get(hObject,'Value'));
vol_clay=100-vol_calcite-vol_quartz;
set(handles.edit1,'String',num2str(vol_clay));
set(handles.edit2,'String',num2str(vol_quartz));
set(handles.slider1,'Value',vol_clay);

calculate_vrh(handles);
% draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
vol_calcite = floor(get(hObject,'Value'));
vol_clay=100-vol_calcite;
vol_quartz=0;
set(handles.edit3,'String',num2str(vol_calcite));
set(handles.edit1,'String',num2str(vol_clay));
set(handles.edit2,'String',num2str(vol_quartz));
set(handles.slider1,'max',100-vol_calcite);
set(handles.slider1,'Value',vol_clay);
set(handles.slider2,'max',100-vol_calcite);
set(handles.slider2,'Value',vol_quartz);

calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
vol_clay=str2double(get(hObject,'String'));
vol_calcite=str2double(get(handles.edit3,'String'));
set(handles.slider1,'Max',100-vol_calcite);
set(handles.slider2,'Max',100-vol_calcite);
if isnumeric(vol_clay) && vol_clay>=get(handles.slider1,'Min') && ...
     vol_clay<=get(handles.slider1,'Max'),
     vol_quartz=100-vol_clay-vol_calcite;
     set(handles.slider3,'Value',vol_calcite);
     set(handles.slider1,'Value',vol_clay);
     set(handles.slider2,'Value',vol_quartz);
     set(handles.edit2,'String',num2str(vol_quartz));
else
     errordlg('You have entered an invalid number','MATLAB error');
end

calculate_vrh(handles);


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
vol_quartz=str2double(get(hObject,'String'));
vol_calcite=str2double(get(handles.edit3,'String'));
set(handles.slider1,'Max',100-vol_calcite);
set(handles.slider2,'Max',100-vol_calcite);
if isnumeric(vol_quartz) && vol_quartz>=get(handles.slider2,'Min') && ...
     vol_quartz<=get(handles.slider2,'Max'),
     vol_clay=100-vol_quartz-vol_calcite;
     set(handles.slider3,'Value',vol_calcite);
     set(handles.slider1,'Value',vol_clay);
     set(handles.slider2,'Value',vol_quartz);
     set(handles.edit1,'String',num2str(vol_clay));
else
     errordlg('You have entered an invalid number','MATLAB error');
end

calculate_vrh(handles);


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
vol_calcite=str2double(get(hObject,'String'));
if isnumeric(vol_calcite) && vol_calcite>=get(handles.slider3,'Min') && ...
     vol_calcite<=get(handles.slider3,'Max'),
     vol_clay=100-vol_calcite;
     vol_quartz=0;
     set(handles.slider3,'Value',vol_calcite);
     set(handles.slider1,'max',100-vol_calcite);
     set(handles.slider1,'Value',vol_clay);
     set(handles.slider2,'max',100-vol_calcite);
     set(handles.slider2,'Value',vol_quartz);
     set(handles.edit1,'String',num2str(vol_clay));
     set(handles.edit2,'String',num2str(vol_quartz));
else
     errordlg('You have entered an invalid number','MATLAB error');
end

calculate_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ok.
function ok_Callback(hObject, eventdata, handles)
% hObject    handle to ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
calculate_vrh(handles);
draw_vrh(handles);


% --- Executes on button press in cancel.
function cancel_Callback(hObject, eventdata, handles)
% hObject    handle to cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(vrh);


function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);

% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double
val=str2double(get(hObject,'String'));
if isnan(val);
   errordlg('You have entered an invalid number','MATLAB error');
end
calculate_vrh(handles);
draw_vrh(handles);


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function calculate_vrh(handles)
%this function get all the values from edits and commence calculation of 
%Voigt-Reuss-Hill average
vol_clay=str2double(get(handles.edit1,'String'))/100;
vol_quartz=str2double(get(handles.edit2,'String'))/100;
vol_calcite=str2double(get(handles.edit3,'String'))/100;
k_clay=str2double(get(handles.edit4,'String'));
mu_clay=str2double(get(handles.edit5,'String'));
rho_clay=str2double(get(handles.edit6,'String'));
k_quartz=str2double(get(handles.edit7,'String'));
mu_quartz=str2double(get(handles.edit8,'String'));
rho_quartz=str2double(get(handles.edit9,'String'));
k_calcite=str2double(get(handles.edit10,'String'));
mu_calcite=str2double(get(handles.edit11,'String'));
rho_calcite=str2double(get(handles.edit12,'String'));

kv=vol_clay*k_clay+vol_quartz*k_quartz+vol_calcite*k_calcite;
kr=1/(vol_clay/k_clay+vol_quartz/k_quartz+vol_calcite/k_calcite);
kvrh=(kv+kr)/2;
kvrh=floor(kvrh*100)/100;

muv=vol_clay*mu_clay+vol_quartz*mu_quartz+vol_calcite*mu_calcite;
mur=1/(vol_clay/mu_clay+vol_quartz/mu_quartz+vol_calcite/mu_calcite);
muvrh=(muv+mur)/2;
muvrh=floor(muvrh*100)/100;

rho=vol_clay*rho_clay+vol_quartz*rho_quartz+vol_calcite*rho_calcite;
rho=floor(rho*100)/100;
vp=sqrt((kvrh+4/3*muvrh)/rho);
vp=floor(vp*1000)/1000;
vs=sqrt(muvrh/rho);
vs=floor(vs*1000)/1000;

set(handles.edit13,'String',num2str(kvrh));
set(handles.edit14,'String',num2str(muvrh));
set(handles.edit15,'String',num2str(rho));
set(handles.edit16,'String',num2str(vp));
set(handles.edit17,'String',num2str(vs));


function draw_vrh(handles)
global vol_clay kvrh muvrh vp vs;
vol_calcite=str2double(get(handles.edit3,'String'))/100;
k_clay=str2double(get(handles.edit4,'String'));
mu_clay=str2double(get(handles.edit5,'String'));
rho_clay=str2double(get(handles.edit6,'String'));
k_quartz=str2double(get(handles.edit7,'String'));
mu_quartz=str2double(get(handles.edit8,'String'));
rho_quartz=str2double(get(handles.edit9,'String'));
k_calcite=str2double(get(handles.edit10,'String'));
mu_calcite=str2double(get(handles.edit11,'String'));
rho_calcite=str2double(get(handles.edit12,'String'));

ivol=1-vol_calcite;

vol_clay=0:0.01:ivol;
vol_quartz=1-vol_calcite-vol_clay;
kv=vol_clay*k_clay+vol_quartz*k_quartz+vol_calcite*k_calcite;
kr=1./(vol_clay/k_clay+vol_quartz/k_quartz+vol_calcite/k_calcite);
kvrh=(kv+kr)/2;

muv=vol_clay*mu_clay+vol_quartz*mu_quartz+vol_calcite*mu_calcite;
mur=1./(vol_clay/mu_clay+vol_quartz/mu_quartz+vol_calcite/mu_calcite);
muvrh=(muv+mur)/2;

rho=vol_clay*rho_clay+vol_quartz*rho_quartz+vol_calcite*rho_calcite;
vp=sqrt((kvrh+4/3*muvrh)./rho);
vs=sqrt(muvrh./rho);

%%draw moduli and velocities
cla(handles.axes1,'reset');
axes(handles.axes1);
plot(vol_clay*100,kvrh,'r','linewidth',2);hold on,
plot(vol_clay*100,muvrh,'b','linewidth',2);
xlim([0 ivol*100]);
legend('Bulk modulus','Shear Modulus');
xlabel('clay content(%)');
ylabel('Moduli');
grid on;

cla(handles.axes2,'reset');
axes(handles.axes2);
plot(vol_clay*100,vp,'r','linewidth',2);hold on,
plot(vol_clay*100,vs,'b','linewidth',2);
xlim([0 ivol*100]);
legend('Vp','Vs');
xlabel('clay content(%)');
ylabel('velocities');
grid on;

function savedata()
global vol_clay kvrh muvrh vp vs;
n=length(vol_clay);
File='data\vrh.dat';
[fidGrd,msg] = fopen(File,'wt');
fprintf(fidGrd,'vol_clay  kvrh  muvrh  vp  vs\n');
for i=1:n,
fprintf(fidGrd,'%e %e %e %e %e\n',vol_clay(i),kvrh(i),muvrh(i),vp(i),vs(i));
end
format short e
fclose(fidGrd);
msgbox('file has been saved!');

% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
savedata();
