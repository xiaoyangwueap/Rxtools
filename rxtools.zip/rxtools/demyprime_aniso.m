function yprime=demyprime_aniso(t,y)

global DEMINPT;
cb11=DEMINPT(1);
cb12=DEMINPT(2);
cb13=DEMINPT(3);
cb33=DEMINPT(4);
cb44=DEMINPT(5);
cb66=DEMINPT(6);
ci11=DEMINPT(7);
ci12=DEMINPT(8);
ci13=DEMINPT(9);
ci33=DEMINPT(10);
ci44=DEMINPT(11);
ci66=DEMINPT(12);
asp=DEMINPT(13);
phic=DEMINPT(14);

yprime=zeros(5,1);

G=zeros(6);
I=eye(6);
Q=zeros(6);
Cdem=zeros(6);
K=zeros(6);
S=[0 0 0 0 0 0 0];

Ci=[ci11 ci12 ci13 0 0 0      %elastic tensor of inclusion(mineral)
    ci12 ci11 ci13 0 0 0
    ci13 ci13 ci33 0 0 0
    0 0 0 2*ci44 0 0
    0 0 0 0 2*ci44 0
    0 0 0 0 0 2*ci66];
Cdem=[y(1) y(1)-2*y(5) y(3) 0 0 0; %y(1)-->c11 y(2)-->c33 y(3)-->c13 y(4)-->c44  y(5)-->c66
      y(1)-2*y(5) y(1) y(3) 0 0 0; 
      y(3) y(3) y(2) 0 0 0; 
      0 0 0 2*y(4) 0 0; 
      0 0 0 0 2*y(4) 0; 
      0 0 0 0 0 2*y(5)];
 
[S(1),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,1),0,1,1e-6);
[S(2),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,2),0,1,1e-6);
[S(3),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,3),0,1,1e-6);
[S(4),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,4),0,1,1e-6);
[S(5),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,5),0,1,1e-6);
[S(6),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,6),0,1,1e-6);
[S(7),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp,7),0,1,1e-6);

g1111=S(1);g2222=S(1);
g3333=S(2);
g1122=S(3);g2211=S(3);
g1133=S(4);g2233=S(4);
g3311=S(5);g3322=S(5);
g1212=S(6);
g1313=S(7);g2323=S(7);

G1111=(g1111+g1111)/(8*pi);
G1122=(g1212+g1212)/(8*pi);   %Gijkl=1/(8*pi)*(gikjl+gjkil)
G1133=(g1313+g1313)/(8*pi);
G2222=(g2222+g2222)/(8*pi);
G3311=(g1313+g1313)/(8*pi);
G3333=(g3333+g3333)/(8*pi);
G1313=(g1133+g1313)/(8*pi);
G1212=(g1122+g1212)/(8*pi);

G=[G1111 G1122 G1133 0 0 0;
   G1122 G2222 G1133 0 0 0;
   G3311 G3311 G3333 0 0 0;
   0 0 0 2*G1313 0 0;
   0 0 0 0 2*G1313 0;
   0 0 0 0 0 2*G1212;];

Q=I+G*(Ci-Cdem);
K=(Ci-Cdem)*inv(Q);
yprime(1)=K(1,1)/(1-t);
yprime(2)=K(3,3)/(1-t);
yprime(3)=K(1,3)/(1-t);
yprime(4)=K(4,4)/(1-t)/2;
yprime(5)=K(6,6)/(1-t)/2;
