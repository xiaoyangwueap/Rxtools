function [kbr,rhobr]=wood(k,rho,x)
%WOOD - Effective elastic moduli for multi-component composite
% using Wood's formula
% can be used for suspension of mixture, such as oil/gas/water/quartz
%
%[KBR,MUBR]=wood(K,MU,ASP,X)
%	K:         Bulk and shear moduli of the N constituent
%		       phases (K, MU, vectors of length N)
%   X:         Fraction of each phase. Sum(X) should be 1.
%	KBR:       Effective bulk and shear moduli 
%
% Written by Zhiqi Guo, 2011
%
%************** Wood's formula *****************

kbr   = (sum(x./k)).^(-1);
rhobr = sum(rho.*x);
