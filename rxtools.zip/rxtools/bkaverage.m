%Calculate stiffness tensor coefficients for shale-kerogen composite, given
%individual Voigt-stiffness-tensors and volume ratios

function [C] = bkaverage(Ys, Yk, xk, alpha)

xs = 1- xk;

%Ys and Yk are stiffness tensors for shale and kerogen. xs and xk are
%volume fractions of shale and kerogen.
%alpha is a coefficient accounting for the degree of lateral discontinuity
%of the shale laminae.


C11 = (Ys(1,1) - ((Ys(1,3))^2)/Ys(3,3))*xs + (Yk(1,1) - ((Yk(1,3))^2)/Yk(3,3))*xk...
    + 1/(xs/(Ys(3,3)) + xk/Yk(3,3))...
    * ((xs*Ys(1,3)/Ys(3,3) + xk*Yk(1,3)/Yk(3,3))^2);

C33 = 1/(xs/Ys(3,3) + xk/Yk(3,3));

C44 = 1/(xs/Ys(4,4) + xk/Yk(4,4));

C66 = xs*Ys(6,6) + xk*Yk(6,6);

C12 = C11 - (xs*Ys(1,1) + xk*Yk(1,1)) + (xs*Ys(1,2) + xk*Yk(1,2));

C13 = (xs*Ys(1,3)/Ys(3,3) + xk*Yk(1,3)/Yk(3,3))/(xs/Ys(3,3) + xk/Yk(3,3));

%Coefficients modified (Vernik and Landis 1996, P.543):

N = 1/(xs/Ys(1,1) + xk/Yk(1,1));

C11 = alpha*C11 + (1 - alpha)*N;

Q = 1/(xs/Ys(6,6) + xk/Yk(6,6));

C66 = alpha*C66 + (1 - alpha)*Q;




C = [C11; C12; C13; C33; C44; C66];