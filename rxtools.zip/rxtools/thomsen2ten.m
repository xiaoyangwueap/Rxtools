function c=thomsen2cVTI(r,vp,vs,epsi,delt,gama)
% ----------------------------------------------------------------------- %
% function c=w_thomsen2c(r,vp,vs,epsi,delt,gama)
%   From Thomsen anisotropy parameters to Cij
% 
%   input:
%       r: density in kg/m3
%       vp,vs: velocities in km/s
%   output:
%       c: stiffness in GPa
% 
% ----------------------------------------------------------------------- %

    c=zeros(6,6);
    c(3,3) = vp*vp;
    temp1 =  vp*vp;
    c(5,5) = vs*vs;
    temp2  = vs*vs;
    c(1,1) = 2.* temp1*epsi + temp1;
    temp1 = 2.* delt *temp1 *(temp1-temp2)+(temp1-temp2)*(temp1-temp2);
    %if(temp1 < 0.) stop'thomsen parameters convertsion error in subroutine thomsen2stiffness'
    c(1,3) = sqrt(temp1)-temp2;
    c(6,6) = 2.*temp2*gama + temp2;
    c(4,4) = temp2; 
    c(5,5) = c(4,4);
    c(2,2) =c(1,1);
    c(1,2) =c(1,1)-2*c(6,6);
    c(2,3) =c(1,3);
    c(2,1)=c(1,2);
    c(3,1)=c(1,3);
    c(3,2)=c(2,3);
    c=c*r;