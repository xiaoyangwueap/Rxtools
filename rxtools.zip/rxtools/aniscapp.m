function [Csca_final]=aniscapp(c1,c2,asp1,asp2,po)
% c2 has to be the stiffness phase, c1 then be the softer phase,
% po means the fraction of phase 1 and it can be a vector.

k1=c1(1,1)-4/3*c1(4,4);
mu1=c1(4,4);

k2=c2(1,1)-4/3*c2(4,4);
mu2=c2(4,4);

c1=[c1,c1(:,4,:),c1(:,5,:),c1(:,6,:)];
c1=[c1;c1(4,:,:);c1(5,:,:);c1(6,:,:)];

c2=[c2,c2(:,4,:),c2(:,5,:),c2(:,6,:)];
c2=[c2;c2(4,:,:);c2(5,:,:);c2(6,:,:)];

asp= [asp1 ,asp2];

if asp(1)==1.
   asp(1)=0.99;
end
if asp(2)==1.
   asp(2)=0.99;
end

% po=[0.0:0.01:1];
Csca_final=zeros(9,9,length(po));

epsilon=1e-7;
for V=1:length(po)
if po(V)==0, po(V)=po(V)+epsilon;end;
if po(V)==1, po(V)=po(V)-epsilon;end;
x=[po(V),1-po(V) ];


%%%%%%% Voigt average for inital sca model
ksca=k1*x(1)+k2*x(2);
musca=mu1*x(1)+mu2*x(2);
[Ssca,Csca]=CSiso(ksca,musca);
Csca=[Csca,Csca(:,4,:),Csca(:,5,:),Csca(:,6,:)];
Csca=[Csca;Csca(4,:,:);Csca(5,:,:);Csca(6,:,:)];

Cnew=zeros(9);
knew=0;
munew=0;
I=eye(9);
Q=zeros(9);
G=zeros(9);
S=[0 0 0 0 0 0 0];


tol=1e-6*Csca(1,1);
del=abs(ksca-knew);
niter=0;



while( (del > abs(tol)) & (niter<3000) )
    
     %%%����������״����G
        
        y=[Csca(1,1) Csca(3,3) Csca(1,3) Csca(4,4) Csca(6,6)];
        
    [S(1),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),1),0,1,1e-6);
    [S(2),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),2),0,1,1e-6);
    [S(3),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),3),0,1,1e-6);
    [S(4),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),4),0,1,1e-6);
    [S(5),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),5),0,1,1e-6);
    [S(6),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),6),0,1,1e-6);
    [S(7),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(1),7),0,1,1e-6);

    g1111=S(1);g2222=S(1);
    g3333=S(2);
    g1122=S(3);g2211=S(3);
    g1133=S(4);g2233=S(4);
    g3311=S(5);g3322=S(5);
    g1212=S(6);
    g1313=S(7);g2323=S(7);

    G1111=(g1111+g1111)/(8*pi);
    G1122=(g1212+g1212)/(8*pi);   %Gijkl=1/(8*pi)*(gikjl+gjkil)
    G1133=(g1313+g1313)/(8*pi);
    G2211=(g1212+g1212)/(8*pi);
    G2222=(g2222+g2222)/(8*pi);
    G2233=(g2323+g2323)/(8*pi);
    G3311=(g1313+g1313)/(8*pi); 
    G3322=(g2323+g2323)/(8*pi);
    G3333=(g3333+g3333)/(8*pi);
    G2323=(g2233+g2323)/(8*pi);
    G1313=(g1133+g1313)/(8*pi);
    G1212=(g1122+g1212)/(8*pi);
    G2332=(g2323+g3322)/(8*pi);
    G1331=(g1313+g3311)/(8*pi);
    G1221=(g1212+g2211)/(8*pi);
    G3223=(g2323+g2233)/(8*pi);
    G3113=(g1313+g1133)/(8*pi);
    G2112=(g1212+g1122)/(8*pi);
    G3232=(g3322+g2323)/(8*pi);
    G3131=(g3311+g1313)/(8*pi);
    G2121=(g2211+g1212)/(8*pi);

    G1=[G1111 G1122 G1133  0    0     0     0     0     0;
              G2211 G2222 G2233  0    0     0     0     0     0;
              G3311 G3322 G3333  0    0     0     0     0     0;
               0      0       0 G2323  0     0   G2332   0     0;
               0      0       0   0   G1313  0     0   G1331   0;
               0      0       0   0    0   G1212   0     0   G1221;
               0      0       0 G3223  0     0   G3232   0     0;
               0      0       0   0  G3113   0     0   G3131   0;
               0      0       0   0    0   G2112   0     0 G2121];
%-------------------------------------------------------------------------
    
    [S(1),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),1),0,1,1e-6);
    [S(2),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),2),0,1,1e-6);
    [S(3),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),3),0,1,1e-6);
    [S(4),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),4),0,1,1e-6);
    [S(5),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),5),0,1,1e-6);
    [S(6),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),6),0,1,1e-6);
    [S(7),n]=quadl(@(x)fint(x,y(1),y(1)-2*y(5),y(3),y(2),y(4),asp(2),7),0,1,1e-6);
    
    g1111=S(1);g2222=S(1);
    g3333=S(2);
    g1122=S(3);g2211=S(3);
    g1133=S(4);g2233=S(4);
    g3311=S(5);g3322=S(5);
    g1212=S(6);
    g1313=S(7);g2323=S(7);

    G1111=(g1111+g1111)/(8*pi);
    G1122=(g1212+g1212)/(8*pi);   %Gijkl=1/(8*pi)*(gikjl+gjkil)
    G1133=(g1313+g1313)/(8*pi);
    G2211=(g1212+g1212)/(8*pi);
    G2222=(g2222+g2222)/(8*pi);
    G2233=(g2323+g2323)/(8*pi);
    G3311=(g1313+g1313)/(8*pi);
    G3322=(g2323+g2323)/(8*pi);
    G3333=(g3333+g3333)/(8*pi);
    G2323=(g2233+g2323)/(8*pi);
    G1313=(g1133+g1313)/(8*pi);
    G1212=(g1122+g1212)/(8*pi);
    G2332=(g2323+g3322)/(8*pi);
    G1331=(g1313+g3311)/(8*pi);
    G1221=(g1212+g2211)/(8*pi);
    G3223=(g2323+g2233)/(8*pi);
    G3113=(g1313+g1133)/(8*pi);
    G2112=(g1212+g1122)/(8*pi);
    G3232=(g3322+g2323)/(8*pi);
    G3131=(g3311+g1313)/(8*pi);
    G2121=(g2211+g1212)/(8*pi);

    G2=[G1111 G1122 G1133  0    0     0     0     0     0;
              G2211 G2222 G2233  0    0     0     0     0     0;
              G3311 G3322 G3333  0    0     0     0     0     0;
               0      0       0 G2323  0     0   G2332   0     0;
               0      0       0   0   G1313  0     0   G1331   0;
               0      0       0   0    0   G1212   0     0   G1221;
               0      0       0 G3223  0     0   G3232   0     0;
               0      0       0   0  G3113   0     0   G3131   0;
               0      0       0   0    0   G2112   0     0 G2121];
   
%-----------------------------------------------------------------------

       Q1=inv(I+G1*(c1-Csca));
       Q2=inv(I+G2*(c2-Csca));
       
       Cnew=(po(V)*c1*Q1+(1-po(V))*c2*Q2)*inv(po(V)*Q1+(1-po(V))*Q2);
       knew=Cnew(1,1)-4/3*Cnew(4,4);
       munew=Cnew(4,4);
   
       del=abs(ksca-knew);
    
       Csca=Cnew;
       ksca=knew;
       musca=munew;
    niter=niter+1;
    
end

Csca_final(:,:,V)=Csca;

end

c11_3=Csca_final(1,1,:);
c33_3=Csca_final(3,3,:);
c44_3=Csca_final(4,4,:);
c66_3=Csca_final(6,6,:);
c13_3=Csca_final(1,3,:);

for i=1:(length(real(Csca_final(1,1,:))))
    C11(i)=c11_3(:,:,i);
    C33(i)=c33_3(:,:,i);
    C13(i)=c13_3(:,:,i);
    C44(i)=c44_3(:,:,i);
    C66(i)=c66_3(:,:,i);
end

k=C11-4/3*C44;
mu=C44;

% %%%iso SCA
% asp1=1;asp2=1;
% [kiso,muiso,poiso]=sca(kq,muq,kw,muw,asp1,asp2);


% for i=1:length(po)
%   %%HSbound
%     f_hs=[po(i) ,1-po(i)];
%     kk=[ k1 k2];
%     mmu=[ mu1 mu2 ];
%     [kup(i) muup(i) klow(i) mulow(i)]=HS(kk,mmu,f_hs);
%     i=i+1;
% end

%��Plotting
% figure,plot(po(1:length(C11)),C11,'-r',po(1:length(C11)),C33,'-b', 'linewidth', 2);
% legend('c11','c33','Location','NorthEast');
% xlabel('po v%'),ylabel('stiffness');
% figure,plot(po(1:length(C11)),C44,'-r',po(1:length(C11)),C66,'-b', 'linewidth', 2);
% legend('c44','c66','Location','NorthEast');
% xlabel('po v%'),ylabel('stiffness');
% figure,plot(po(1:length(C11)),C13,'-b', 'linewidth', 2);
% legend('c13','Location','NorthEast');
% xlabel('po v%'),ylabel('stiffness');
% figure,plot(po(1:length(C11)),k,'*r',po(1:length(C11)),mu,'*k', 'linewidth', 2);
% hold on; plot(po(1:length(C11)),kup,'-r',po(1:length(C11)),klow,'-r', 'linewidth', 2);
% hold on; plot(po(1:length(C11)),muup,'--k',po(1:length(C11)),mulow,'--k', 'linewidth', 2);
% 