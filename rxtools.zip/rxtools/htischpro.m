function [Rpp,Rps,Rpt,ang]=htischpro(CC1,RHO1,CC2,RHO2,phi)
%C111=46.03; C221=46.03; C331=33.52; C121=11.35; C131=9.90; C231=9.90; C441=9.05; C551=9.05; C661=17.34;
%C112=23.474; C222=23.474; C332=16.767; C122=7.522; C132=8.062; C232=8.062; C442=5.698; C552=5.698; C662=7.976;
%RHO1=2.39; RHO2=2.3; %%Input VTI shale model
C111=CC1(1);
C131=CC1(2);
C121=C131;
C331=CC1(3);
C221=C331;
C441=CC1(4);
C661=CC1(5);
C551=C661;
C231=C331-2*C441;

C112=CC2(1);
C132=CC2(2);
C122=C132;
C332=CC2(3);
C222=C332;
C442=CC2(4);
C662=CC2(5);
C552=C662;
C232=C332-2*C442;
% Z_N=1/90; Z_V=1/8; Z_H=1/8;
% sigma_N1=(Z_N*31.65)/(1+Z_N*31.65);
% sigma_V1=(Z_V*9.05)/(1+Z_V*9.05);
% sigma_H1=(Z_H*9.05)/(1+Z_H*9.05);
% sigma_N2=(Z_N*16.767)/(1+Z_N*16.767);
% sigma_V2=(Z_V*5.698)/(1+Z_V*5.698);
% sigma_H2=(Z_H*5.698)/(1+Z_H*5.698);
% 
% C111=31.65*(1-sigma_N1); 
% C221=31.65*(1-sigma_N1*13.55^2/31.65^2); 
% C331=31.65*(1-sigma_N1*13.55^2/31.65^2); 
% C121=13.55*(1-sigma_N1);
% C131=13.55*(1-sigma_N1);
% C231=13.55*(1-sigma_N1*13.55/31.65);
% C441=9.05; 
% C551=9.05*(1-sigma_V1); 
% C661=9.05*(1-sigma_H1);
% 
% C112=16.767*(1-sigma_N2); 
% C222=16.767*(1-sigma_N2*5.371^2/16.767^2); 
% C332=16.767*(1-sigma_N2*5.371^2/16.767^2); 
% C122=5.371*(1-sigma_N2);
% C132=5.371*(1-sigma_N2); 
% C232=5.371*(1-sigma_N2*5.371/16.767); 
% C442=5.698; 
% C552=5.698*(1-sigma_V2); 
% C662=5.698*(1-sigma_H2);
% 
% RHO1=2.39; RHO2=2.3;

S1p=zeros(90,1); S2p=zeros(90,1); S3p=zeros(90,1);
S1s=zeros(90,1); S2s=zeros(90,1); S3s=zeros(90,1);
S1t=zeros(90,1); S2t=zeros(90,1); S3t=zeros(90,1);
V1p=zeros(90,1); V2p=zeros(90,1); V3p=zeros(90,1);
V1s=zeros(90,1); V2s=zeros(90,1); V3s=zeros(90,1);
V1t=zeros(90,1); V2t=zeros(90,1); V3t=zeros(90,1);
%phi=0;
X1=zeros(3,3); Y1=zeros(3,3);
X2=zeros(3,3); Y2=zeros(3,3);
R=zeros(3,3); T=zeros(3,3);
Rpp=zeros(91,1); Rps=zeros(91,1); Rpt=zeros(91,1);
Rsp=zeros(91,1); Rss=zeros(91,1); Rst=zeros(91,1);
Rtp=zeros(91,1); Rts=zeros(91,1); Rtt=zeros(91,1);
Tpp=zeros(91,1); Tps=zeros(91,1); Tpt=zeros(91,1);
Tsp=zeros(91,1); Tss=zeros(91,1); Tst=zeros(91,1);
Ttp=zeros(91,1); Tts=zeros(91,1); Ttt=zeros(91,1);

for theta=1:90;
    n1=cos(pi*phi/180)*sin(pi*theta/180);
    n2=sin(pi*phi/180)*sin(pi*theta/180);
    n3=cos(pi*theta/180);
    x1=(C111*n1^2+C661*n2^2+C551*n3^2)/RHO1;
    x2=(C661*n1^2+C221*n2^2+C441*n3^2)/RHO1;
    x3=(C551*n1^2+C441*n2^2+C331*n3^2)/RHO1;
    x4=(C121+C661)*n1*n2/RHO1;
    x5=(C131+C551)*n1*n3/RHO1;
    x6=(C231+C441)*n2*n3/RHO1;
    S = [x1 x4 x5; x4 x2 x6; x5 x6 x3];
    [V,D]=eig(S);
    if (D(1,1)>=D(2,2)>=D(3,3))||(D(1,1)>=D(3,3)>=D(2,2))
    A(1)=1/D(1,1);
    else if (D(2,2)>=D(1,1)>=D(3,3))||(D(2,2)>=D(3,3)>=D(1,1))
            A(1)=1/D(2,2);
        else A(1)=1/D(3,3);
        end
    end
    
    S1p(theta,1)=sqrt(A(1))*n1;
    S2p(theta,1)=sqrt(A(1))*n2;
    S1s(theta,1)=sqrt(A(1))*n1;
    S2s(theta,1)=sqrt(A(1))*n2;
    S1t(theta,1)=sqrt(A(1))*n1;
    S2t(theta,1)=sqrt(A(1))*n2;
    V1p(theta,1)=sqrt(A(1))*n1;
    V2p(theta,1)=sqrt(A(1))*n2;
    V1s(theta,1)=sqrt(A(1))*n1;
    V2s(theta,1)=sqrt(A(1))*n2;
    V1t(theta,1)=sqrt(A(1))*n1;
    V2t(theta,1)=sqrt(A(1))*n2;
    
    x11=C111.*(S1p(theta,1).^2)+C661.*(S2p(theta,1).^2)-RHO1;
    x21=C661.*(S1s(theta,1).^2)+C221.*(S2s(theta,1).^2)-RHO1;
    x31=C551.*(S1t(theta,1).^2)+C441.*(S2t(theta,1).^2)-RHO1;
    x41=(C121+C661).*S1p(theta,1).*S2p(theta,1);
    x51=(C131+C551).*S1p(theta,1);
    x61=(C231+C441).*S2p(theta,1);
    a=C331*C441*C551;
    b=x11*C331*C441+x21*C331*C551+x31*C441*C551-(x51^2)*C441-(x61^2)*C551;
    c=x11*x21*C331+x11*x31*C441+x21*x31*C551-(x41^2)*C331+2*x41*x51*x61-x11*(x61^2)-x21*(x51^2);
    d=x11*x21*x31-x31*(x41^2);
    %S1=bicubic(a,b,c,d);
    S1=roots([a b c d]);
    S3p(theta,1)=real(sqrt(real(S1(3)))); S3s(theta,1)=real(sqrt(real(S1(2)))); S3t(theta,1)=real(sqrt(real(S1(1))));
    
    a1=C111.*(S1p(theta,1).^2)+C661.*(S2p(theta,1).^2)+C551.*(S3p(theta,1).^2);
    a2=C661.*(S1p(theta,1).^2)+C221.*(S2p(theta,1).^2)+C441.*(S3p(theta,1).^2);
    a3=C551.*(S1p(theta,1).^2)+C441.*(S2p(theta,1).^2)+C331.*(S3p(theta,1).^2);
    a4=(C121+C661).*S1p(theta,1).*S2p(theta,1);
    a5=(C131+C551).*S1p(theta,1).*S3p(theta,1);
    a6=(C231+C441).*S2p(theta,1).*S3p(theta,1);
    Ap1=[a1 a4 a5; a4 a2 a6; a5 a6 a3];
    [Vp1,Dp1]=eig(Ap1);
    if abs(RHO1-Dp1(1,1))<1e-6
    ep1(1)=abs(Vp1(1,1)); ep1(2)=abs(Vp1(2,1)); ep1(3)=abs(Vp1(3,1));
    else if abs(RHO1-Dp1(2,2))<1e-6
            ep1(1)=abs(Vp1(1,2)); ep1(2)=abs(Vp1(2,2)); ep1(3)=abs(Vp1(3,2));
        else
            ep1(1)=abs(Vp1(1,3)); ep1(2)=abs(Vp1(2,3)); ep1(3)=abs(Vp1(3,3));
        end
    end
    
    %%
        dd = S1s*ep1(1) + S2s*ep1(2);
    if dd < 0,
        ep1(1)=-ep1(1);
        ep1(2)=-ep1(2);
        ep1(3)=-ep1(3);
    end
    %%
    
    b1=C111.*(S1s(theta,1).^2)+C661.*(S2s(theta,1).^2)+C551.*(S3s(theta,1).^2);
    b2=C661.*(S1s(theta,1).^2)+C221.*(S2s(theta,1).^2)+C441.*(S3s(theta,1).^2);
    b3=C551.*(S1s(theta,1).^2)+C441.*(S2s(theta,1).^2)+C331.*(S3s(theta,1).^2);
    b4=(C121+C661).*S1s(theta,1).*S2s(theta,1);
    b5=(C131+C551).*S1s(theta,1).*S3s(theta,1);
    b6=(C231+C441).*S2s(theta,1).*S3s(theta,1);
    As1=[b1 b4 b5; b4 b2 b6; b5 b6 b3];
    [Vs1,Ds1]=eigs(As1);
    if abs(RHO1-Ds1(1,1))<1e-6
    es1(1)=Vs1(1,1); es1(2)=Vs1(2,1); es1(3)=Vs1(3,1);
    else if abs(RHO1-Ds1(2,2))<1e-6
            es1(1)=Vs1(1,2); es1(2)=Vs1(2,2); es1(3)=Vs1(3,2);
        else 
            es1(1)=Vs1(1,3); es1(2)=Vs1(2,3); es1(3)=Vs1(3,3);
        end
    end  %non-uniqueness of eigen vector leading to jump of reflectivity.
    %%
    dd = S1s*es1(1) + S2s*es1(2) ;
    if dd < 0,
        es1(1)=-es1(1);
        es1(2)=-es1(2);
        es1(3)=-es1(3);
    end
    %%
    
    c1=C111.*(S1t(theta,1).^2)+C661.*(S2t(theta,1).^2)+C551.*(S3t(theta,1).^2);
    c2=C661.*(S1t(theta,1).^2)+C221.*(S2t(theta,1).^2)+C441.*(S3t(theta,1).^2);
    c3=C551.*(S1t(theta,1).^2)+C441.*(S2t(theta,1).^2)+C331.*(S3t(theta,1).^2);
    c4=(C121+C661).*S1t(theta,1).*S2t(theta,1);
    c5=(C131+C551).*S1t(theta,1).*S3t(theta,1);
    c6=(C231+C441).*S2t(theta,1).*S3t(theta,1);
    At1=[c1 c4 c5; c4 c2 c6; c5 c6 c3];
    [Vt1,Dt1]=eigs(At1);
    if abs(RHO1-Dt1(1,1))<1e-6
    et1(1)=Vt1(1,1); et1(2)=Vt1(2,1); et1(3)=Vt1(3,1);
    else if abs(RHO1-Dt1(2,2))<1e-6
            et1(1)=Vt1(1,2); et1(2)=Vt1(2,2); et1(3)=Vt1(3,2);
        else 
            et1(1)=Vt1(1,3); et1(2)=Vt1(2,3); et1(3)=Vt1(3,3);
        end
    end
    %%
    dd = S1s*et1(1) + S2s*et1(2);
    if dd < 0,
        et1(1)=-et1(1);
        et1(2)=-et1(2);
        et1(3)=-et1(3);
    end
    %%
    
    X1(1,1)=ep1(1); X1(1,2)=es1(1); X1(1,3)=et1(1);
    X1(2,1)=ep1(2); X1(2,2)=es1(2); X1(2,3)=et1(2);
    X1(3,1)=-C131.*ep1(1).*S1p(theta,1)-C231.*ep1(2).*S2p(theta,1)-C331.*ep1(3).*S3p(theta,1);
    X1(3,2)=-C131.*es1(1).*S1s(theta,1)-C231.*es1(2).*S2s(theta,1)-C331.*es1(3).*S3s(theta,1);
    X1(3,3)=-C131.*et1(1).*S1t(theta,1)-C231.*et1(2).*S2t(theta,1)-C331.*et1(3).*S3t(theta,1);
    Y1(1,1)=-C551.*S1p(theta,1).*ep1(3)-C551.*ep1(1).*S3p(theta,1);
    Y1(1,2)=-C551.*S1s(theta,1).*es1(3)-C551.*es1(1).*S3s(theta,1);
    Y1(1,3)=-C551.*S1t(theta,1).*et1(3)-C551.*et1(1).*S3t(theta,1);
    Y1(2,1)=-C441.*S2p(theta,1).*ep1(3)-C441.*ep1(2).*S3p(theta,1);
    Y1(2,2)=-C441.*S2s(theta,1).*es1(3)-C441.*es1(2).*S3s(theta,1);
    Y1(2,3)=-C441.*S2t(theta,1).*et1(3)-C441.*et1(2).*S3t(theta,1);
    Y1(3,1)=ep1(3); Y1(3,2)=es1(3); Y1(3,3)=et1(3);
    
    x12=C112.*(V1p(theta,1).^2)+C662.*(V2p(theta,1).^2)-RHO2;
    x22=C662.*(V1s(theta,1).^2)+C222.*(V2s(theta,1).^2)-RHO2;
    x32=C552.*(V1t(theta,1).^2)+C442.*(V2t(theta,1).^2)-RHO2;
    x42=(C122+C662).*V1p(theta,1).*V2p(theta,1);
    x52=(C132+C552).*V1p(theta,1);
    x62=(C232+C442).*V2p(theta,1);
    e=C332*C442*C552;
    f=x12*C332*C442+x22*C332*C552+x32*C442*C552-(x52^2)*C442-(x62^2)*C552;
    g=x12*x22*C332+x12*x32*C442+x22*x32*C552-(x42^2)*C332+2*x42*x52*x62-x12*(x62^2)-x22*(x52^2);
    h=x12*x22*x32-x32*(x42^2);
    %S2=bicubic(e,f,g,h);
    S2=roots([e f g h]);
    V3p(theta,1)=real(sqrt(real(S2(3)))); V3s(theta,1)=real(sqrt(real(S2(2)))); V3t(theta,1)=real(sqrt(real(S2(1))));
    
    d1=C112.*(V1p(theta,1).^2)+C662.*(V2p(theta,1).^2)+C552.*(V3p(theta,1).^2);
    d2=C662.*(V1p(theta,1).^2)+C222.*(V2p(theta,1).^2)+C442.*(V3p(theta,1).^2);
    d3=C552.*(V1p(theta,1).^2)+C442.*(V2p(theta,1).^2)+C332.*(V3p(theta,1).^2);
    d4=(C122+C662).*V1p(theta,1).*V2p(theta,1);
    d5=(C132+C552).*V1p(theta,1).*V3p(theta,1);
    d6=(C232+C442).*V2p(theta,1).*V3p(theta,1);
    Ap2=[d1 d4 d5; d4 d2 d6; d5 d6 d3];
    [Vp2,Dp2]=eig(Ap2);
    if abs(RHO2-Dp2(1,1))<1e-6
    ep2(1)=Vp2(1,1); ep2(2)=Vp2(2,1); ep2(3)=Vp2(3,1);
    else if abs(RHO2-Dp2(2,2))<1e-6
            ep2(1)=Vp2(1,2); ep2(2)=Vp2(2,2); ep2(3)=Vp2(3,2);
        else 
            ep2(1)=Vp2(1,3); ep2(2)=Vp2(2,3); ep2(3)=Vp2(3,3);
        end
    end
    %%
        dd = S1s*ep1(1) + S2s*ep1(2);
    if dd < 0,
        ep1(1)=-ep1(1);
        ep1(2)=-ep1(2);
        ep1(3)=-ep1(3);
    end
    %%
    
    e1=C112.*(V1s(theta,1).^2)+C662.*(V2s(theta,1).^2)+C552.*(V3s(theta,1).^2);
    e2=C662.*(V1s(theta,1).^2)+C222.*(V2s(theta,1).^2)+C442.*(V3s(theta,1).^2);
    e3=C552.*(V1s(theta,1).^2)+C442.*(V2s(theta,1).^2)+C332.*(V3s(theta,1).^2);
    e4=(C122+C662).*V1s(theta,1).*V2s(theta,1);
    e5=(C132+C552).*V1s(theta,1).*V3s(theta,1);
    e6=(C232+C442).*V2s(theta,1).*V3s(theta,1);
    As2=[e1 e4 e5; e4 e2 e6; e5 e6 e3];
    [Vs2,Ds2]=eigs(As2);
    if abs(RHO2-Ds2(1,1))<1e-6
    es2(1)=Vs2(1,1); es2(2)=Vs2(2,1); es2(3)=Vs2(3,1);
    else if abs(RHO2-Ds2(2,2))<1e-6
            es2(1)=Vs2(1,2); es2(2)=Vs2(2,2); es2(3)=Vs2(3,2);
        else 
            es2(1)=Vs2(1,3); es2(2)=Vs2(2,3); es2(3)=Vs2(3,3);
        end
    end
    %%
    dd = S1s*es2(1) + S2s*es2(2);
    if dd < 0,
        es2(1)=-es2(1);
        es2(2)=-es2(2);
        es2(3)=-es2(3);
    end
    %%
    
    f1=C112.*(V1t(theta,1).^2)+C662.*(V2t(theta,1).^2)+C552.*(V3t(theta,1).^2);
    f2=C662.*(V1t(theta,1).^2)+C222.*(V2t(theta,1).^2)+C442.*(V3t(theta,1).^2);
    f3=C552.*(V1t(theta,1).^2)+C442.*(V2t(theta,1).^2)+C332.*(V3t(theta,1).^2);
    f4=(C122+C662).*V1t(theta,1).*V2t(theta,1);
    f5=(C132+C552).*V1t(theta,1).*V3t(theta,1);
    f6=(C232+C442).*V2t(theta,1).*V3t(theta,1);
    At2=[f1 f4 f5; f4 f2 f6; f5 f6 f3];
    [Vt2,Dt2]=eigs(At2);
    if abs(RHO2-Dt2(1,1))<1e-6
    et2(1)=Vt2(1,1); et2(2)=Vt2(2,1); et2(3)=Vt2(3,1);
    else if abs(RHO2-Dt2(2,2))<1e-6
            et2(1)=Vt2(1,2); et2(2)=Vt2(2,2); et2(3)=Vt2(3,2);
        else
            et2(1)=Vt2(1,3); et2(2)=Vt2(2,3); et2(3)=Vt2(3,3);
        end
    end
    %%
    dd = S1s*et2(1) + S2s*et2(2);
    if dd < 0,
        et2(1)=-et2(1);
        et2(2)=-et2(2);
        et2(3)=-et2(3);
    end
    %%
    
    X2(1,1)=ep2(1); X2(1,2)=es2(1); X2(1,3)=et2(1);
    X2(2,1)=ep2(2); X2(2,2)=es2(2); X2(2,3)=et2(2);
    X2(3,1)=-C132.*ep2(1).*V1p(theta,1)-C232.*ep2(2).*V2p(theta,1)-C332.*ep2(3).*V3p(theta,1);
    X2(3,2)=-C132.*es2(1).*V1s(theta,1)-C232.*es2(2).*V2s(theta,1)-C332.*es2(3).*V3s(theta,1);
    X2(3,3)=-C132.*et2(1).*V1t(theta,1)-C232.*et2(2).*V2t(theta,1)-C332.*et2(3).*V3t(theta,1);
    Y2(1,1)=-C552.*V1p(theta,1).*ep2(3)-C552.*ep2(1).*V3p(theta,1);
    Y2(1,2)=-C552.*V1s(theta,1).*es2(3)-C552.*es2(1).*V3s(theta,1);
    Y2(1,3)=-C552.*V1t(theta,1).*et2(3)-C552.*et2(1).*V3t(theta,1);
    Y2(2,1)=-C442.*V2p(theta,1).*ep2(3)-C442.*ep2(2).*V3p(theta,1);
    Y2(2,2)=-C442.*V2s(theta,1).*es2(3)-C442.*es2(2).*V3s(theta,1);
    Y2(2,3)=-C442.*V2t(theta,1).*et2(3)-C442.*et2(2).*V3t(theta,1);
    Y2(3,1)=ep2(3); Y2(3,2)=es2(3); Y2(3,3)=et2(3);
    
    RR=(X1\X2+Y1\Y2);
    R=(X1\X2-Y1\Y2)/(X1\X2+Y1\Y2);
    %T=2./(X1\X2+Y1\Y2);
    Rpp(theta+1,1)=R(1,1); Rps(theta+1,1)=R(1,2); Rpt(theta+1,1)=R(1,3);
    Rsp(theta+1,1)=R(2,1); Rss(theta+1,1)=R(2,2); Rst(theta+1,1)=R(2,3);
    Rtp(theta+1,1)=R(3,1); Rts(theta+1,1)=R(3,2); Rtt(theta+1,1)=R(3,3);
    %Tpp(theta+1,1)=T(1,1); Tps(theta+1,1)=T(1,2); Tpt(theta+1,1)=T(1,3);
    %Tsp(theta+1,1)=T(2,1); Tss(theta+1,1)=T(2,2); Tst(theta+1,1)=T(2,3);
    %Ttp(theta+1,1)=T(3,1); Tts(theta+1,1)=T(3,2); Ttt(theta+1,1)=T(3,3);
    Rpp(1,1)=(sqrt(RHO2*C332)-sqrt(RHO1*C331))/(sqrt(RHO2*C332)+sqrt(RHO1*C331));
end
ang=0:1:90;
%figure,plot(0:90,Rpp);